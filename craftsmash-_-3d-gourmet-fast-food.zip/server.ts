import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const SYSTEM_INSTRUCTION = `You are "Chef Smash", the enthusiastic and knowledgeable AI Food Concierge & Ordering Agent for "CraftSmash™ Gourmet Fast Food".

Brand Details:
- CraftSmash™ specializes in artisanal 450°F double smash burgers made from 100% Halal prime Angus beef, wood-fired artisan pizzas, crispy southern fried chicken, and cheese-loaded fries.
- Locations: Flagships in Lahore (Gulberg III), Islamabad (Beverly Centre, F-7), and Karachi (DHA Phase 6).
- Operating Hours: 12:00 PM to 03:30 AM (Late night delivery available).
- Delivery Time: 25-35 minutes average. Delivery fee is Rs. 150, or FREE for orders above Rs. 2,500.

Menu Highlights (Prices in PKR):
- Burgers:
  * CraftSmash Double Truffle Burger: Rs. 1,050 (Aged cheddar, caramelized onion jam, black truffle garlic aioli)
  * Volcano Crispy Zinger Burger: Rs. 790 (Buttermilk fried chicken, peri-peri glaze, fiery sriracha mayo)
  * Smokey Hickory BBQ Stack: Rs. 980
  * Classic Smash Cheese Burger: Rs. 820
- Pizzas:
  * Artisan Pepperoni Blaze Pizza: Rs. 1,450 (Wood-fired, buffalo mozzarella, hot honey drizzle)
  * Creamy Chicken Tikka Supreme: Rs. 1,390
  * Smoky BBQ Ranch Fajita: Rs. 1,490
- Fried Chicken & Fries:
  * Crispy Golden Drumstick Bucket (6 Pcs): Rs. 1,290
  * Nashville Hot Chicken Tenders (5 Pcs): Rs. 940
  * CraftSmash Cheesy Loaded Fries: Rs. 690 (Liquid cheddar, beef bits, jalapeños)
  * Firecracker Curly Fries: Rs. 490
- Deals & Combos:
  * Smash Duo Feast (For 2): Rs. 2,450 (2x Double Truffle Burgers + Cheesy Loaded Fries + 2x Drinks)
  * Mega Family Crave Box (For 4): Rs. 4,390 (1x Large Pepperoni Pizza + 2x Zinger Burgers + 4x Drumsticks + Loaded Fries + 1.5L Coke)
  * Solo Midnight Box: Rs. 1,390
- Active Promo Vouchers:
  * "SMASH20" gives 20% OFF on orders over Rs. 1,500
  * "FIRSTBITE" gives 15% OFF on orders over Rs. 800

Tone & Style:
- Warm, appetizing, concise, and helpful.
- When recommending items, mention their price in PKR and flavor profile.
- You can suggest adding items to cart or exploring combos.
- Keep responses friendly and under 3-4 sentences unless detailed recommendations are asked.`;

// AI Agent Chat Route
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, userMessage } = req.body;

    if (!userMessage && (!messages || messages.length === 0)) {
      return res.status(400).json({ error: 'Message content is required.' });
    }

    const currentPrompt = userMessage || (messages[messages.length - 1]?.content ?? '');

    // Format chat history for Gemini
    const contents: any[] = [];

    if (messages && messages.length > 1) {
      // Include prior conversational turns
      messages.slice(0, -1).forEach((msg: any) => {
        contents.push({
          role: msg.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: msg.content }],
        });
      });
    }

    contents.push({
      role: 'user',
      parts: [{ text: currentPrompt }],
    });

    if (!process.env.GEMINI_API_KEY) {
      // Intelligent fallback if no API key is provided
      const q = currentPrompt.toLowerCase();
      let fallback = "Welcome to CraftSmash™! I'm Chef Smash, your AI Food Concierge. How can I help with your craving today?";

      if (q.includes('spicy') || q.includes('hot') || q.includes('fire')) {
        fallback = "If you love heat, you must try our Volcano Crispy Zinger Burger (Rs. 790) with fiery peri-peri glaze, or the Nashville Hot Tenders (Rs. 940) paired with Firecracker Curly Fries!";
      } else if (q.includes('deal') || q.includes('combo') || q.includes('2') || q.includes('family')) {
        fallback = "For two people, our Smash Duo Feast (Rs. 2,450) is the top pick: 2x Double Truffle Burgers, Loaded Fries, and 2 Drinks. For groups, the Mega Family Crave Box (Rs. 4,390) saves you over Rs. 800!";
      } else if (q.includes('voucher') || q.includes('code') || q.includes('discount') || q.includes('promo')) {
        fallback = "Use promo code SMASH20 for 20% OFF on orders above Rs. 1,500, or FIRSTBITE for 15% OFF on your first craving!";
      } else if (q.includes('pizza') || q.includes('crust')) {
        fallback = "Our Artisan Pepperoni Blaze Pizza (Rs. 1,450) features blistered wood-fired dough, buffalo mozzarella, and a drizzle of hot honey. It's a customer favorite!";
      } else if (q.includes('branch') || q.includes('location') || q.includes('where')) {
        fallback = "We have 3 flagship kitchens: Gulberg III Lahore, Beverly Centre F-7 Islamabad, and DHA Phase 6 Karachi! All branches deliver hot within 25-35 minutes.";
      }

      return res.json({ reply: fallback });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    const reply = response.text || "I'd love to help with your CraftSmash craving! Could you tell me what flavours you're in the mood for?";
    res.json({ reply });
  } catch (err: any) {
    console.error('Gemini chat error:', err);
    res.status(500).json({
      error: 'Failed to generate response',
      message: err?.message || 'Server error',
      fallback: "I'm having a momentary kitchen connection blip, but our griddle is sizzling! Try our bestseller CraftSmash Double Truffle Burger (Rs. 1,050) or use code SMASH20 for 20% off!"
    });
  }
});

// Full-stack Vite handling
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

startServer();
