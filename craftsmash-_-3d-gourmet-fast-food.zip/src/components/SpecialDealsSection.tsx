import React from 'react';
import { Tag, Users, Flame, Plus, ArrowRight } from 'lucide-react';
import { FoodItem } from '../types.ts';

interface SpecialDealsSectionProps {
  comboItems: FoodItem[];
  onSelectCombo: (item: FoodItem) => void;
  onQuickAdd: (item: FoodItem) => void;
  onViewAllMenu: () => void;
}

export const SpecialDealsSection: React.FC<SpecialDealsSectionProps> = ({
  comboItems,
  onSelectCombo,
  onQuickAdd,
  onViewAllMenu,
}) => {
  return (
    <section className="py-16 md:py-24 bg-[#0c0d10] relative overflow-hidden border-t border-zinc-900">
      {/* Background glow */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-red-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-amber-400 uppercase mb-2">
              <Tag className="w-4 h-4" />
              <span>Special Combos & Family Feasts</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold uppercase font-display text-white tracking-tight leading-none">
              SMASH COMBOS & SAVINGS
            </h2>
            <p className="text-sm text-zinc-400 mt-2 max-w-xl">
              Curated party bundles and duo meals designed for peak satisfaction at unbeatable value.
            </p>
          </div>

          <button
            onClick={onViewAllMenu}
            className="self-start md:self-end px-5 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-800 text-xs font-semibold flex items-center gap-2 transition-colors"
          >
            <span>View All Menu Items</span>
            <ArrowRight className="w-4 h-4 text-red-500" />
          </button>
        </div>

        {/* Deals Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {comboItems.map((deal) => (
            <div
              key={deal.id}
              className="bg-[#14151b] border border-zinc-800/90 hover:border-amber-500/50 rounded-3xl overflow-hidden flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl group"
            >
              {/* Image banner with overlay */}
              <div
                onClick={() => onSelectCombo(deal)}
                className="relative h-56 w-full bg-zinc-900 overflow-hidden cursor-pointer"
              >
                <img
                  src={deal.image}
                  alt={deal.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#14151b] via-transparent to-black/30" />

                {deal.badge && (
                  <span className="absolute top-3 left-3 px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider bg-amber-500 text-black shadow-lg">
                    {deal.badge}
                  </span>
                )}

                <div className="absolute bottom-3 right-3 px-2.5 py-1 rounded-md bg-black/70 backdrop-blur-md text-[11px] font-semibold text-zinc-300 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-amber-400" />
                  <span>Great for sharing</span>
                </div>
              </div>

              {/* Deal info */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <h3
                    onClick={() => onSelectCombo(deal)}
                    className="text-xl font-bold text-white font-display uppercase tracking-wide group-hover:text-amber-400 transition-colors cursor-pointer"
                  >
                    {deal.name}
                  </h3>
                  <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
                    {deal.description}
                  </p>
                </div>

                <div className="pt-5 mt-5 border-t border-zinc-800/80 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-zinc-500 uppercase block font-semibold">
                      Combo Price
                    </span>
                    <span className="text-xl font-bold text-white font-mono tabular-nums">
                      Rs. {deal.price.toLocaleString()}
                    </span>
                  </div>

                  <button
                    onClick={() => onQuickAdd(deal)}
                    className="px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider rounded-xl shadow-lg shadow-red-950/40 transition-all flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Combo</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
