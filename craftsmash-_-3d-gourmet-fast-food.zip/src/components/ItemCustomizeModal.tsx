import React, { useState } from 'react';
import { X, Plus, Minus, Flame, Check } from 'lucide-react';
import { FoodItem, CustomizationOption } from '../types.ts';

interface ItemCustomizeModalProps {
  item: FoodItem | null;
  onClose: () => void;
  onAddToCart: (
    item: FoodItem,
    quantity: number,
    selectedSize: string | undefined,
    selectedExtras: CustomizationOption[],
    notes: string,
    finalUnitPrice: number
  ) => void;
}

export const ItemCustomizeModal: React.FC<ItemCustomizeModalProps> = ({
  item,
  onClose,
  onAddToCart,
}) => {
  if (!item) return null;

  const [quantity, setQuantity] = useState<number>(1);
  const [selectedSize, setSelectedSize] = useState<string | undefined>(
    item.sizes && item.sizes.length > 0 ? item.sizes[0].name : undefined
  );
  const [selectedExtras, setSelectedExtras] = useState<CustomizationOption[]>([]);
  const [notes, setNotes] = useState<string>('');

  // Calculate current unit price
  let sizeMultiplier = 1.0;
  if (selectedSize && item.sizes) {
    const foundSize = item.sizes.find((s) => s.name === selectedSize);
    if (foundSize) sizeMultiplier = foundSize.priceMultiplier;
  }
  const basePriceAfterSize = Math.round(item.price * sizeMultiplier);
  const extrasTotal = selectedExtras.reduce((sum, ext) => sum + ext.price, 0);
  const unitPrice = basePriceAfterSize + extrasTotal;
  const totalPrice = unitPrice * quantity;

  const toggleExtra = (extra: CustomizationOption) => {
    if (selectedExtras.some((e) => e.name === extra.name)) {
      setSelectedExtras(selectedExtras.filter((e) => e.name !== extra.name));
    } else {
      setSelectedExtras([...selectedExtras, extra]);
    }
  };

  const handleConfirm = () => {
    onAddToCart(item, quantity, selectedSize, selectedExtras, notes, unitPrice);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg bg-[#14151b] border border-zinc-800 rounded-3xl shadow-2xl overflow-hidden my-8">
        {/* Header with image banner */}
        <div className="relative h-48 w-full bg-zinc-900 overflow-hidden">
          <img
            src={item.image}
            alt={item.name}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#14151b] via-[#14151b]/40 to-transparent" />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/60 text-zinc-300 hover:text-white hover:bg-black/90 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          {item.badge && (
            <span className="absolute bottom-3 left-4 px-2.5 py-1 text-xs font-bold uppercase rounded bg-red-600 text-white">
              {item.badge}
            </span>
          )}
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
          <div>
            <div className="flex items-start justify-between gap-4">
              <h3 className="text-xl font-bold text-white font-display uppercase tracking-wide">
                {item.name}
              </h3>
              <span className="text-lg font-bold text-amber-400 tabular-nums whitespace-nowrap">
                Rs. {item.price.toLocaleString()}
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">{item.description}</p>
            <div className="flex items-center gap-3 text-[11px] text-zinc-500 mt-2">
              {item.prepTime && <span>Prep: {item.prepTime}</span>}
              {item.calories && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{item.calories} kcal</span>
                </>
              )}
            </div>
          </div>

          {/* Size / Portion Selection (if item has sizes) */}
          {item.sizes && item.sizes.length > 0 && (
            <div className="border-t border-zinc-800/80 pt-4">
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2">
                Choose Size / Portion
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {item.sizes.map((s) => {
                  const isSelected = selectedSize === s.name;
                  const calculatedPrice = Math.round(item.price * s.priceMultiplier);
                  return (
                    <button
                      key={s.name}
                      type="button"
                      onClick={() => setSelectedSize(s.name)}
                      className={`p-2.5 rounded-xl text-left border transition-all ${
                        isSelected
                          ? 'border-red-500 bg-red-600/10 text-white'
                          : 'border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      <div className="text-xs font-semibold truncate">{s.name}</div>
                      <div className="text-[11px] text-amber-400 mt-0.5 tabular-nums">
                        Rs. {calculatedPrice.toLocaleString()}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Extras / Add-ons (if item has extras) */}
          {item.extras && item.extras.length > 0 && (
            <div className="border-t border-zinc-800/80 pt-4">
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2">
                Customize & Add Extras
              </label>
              <div className="space-y-2">
                {item.extras.map((extra) => {
                  const isSelected = selectedExtras.some((e) => e.name === extra.name);
                  return (
                    <button
                      key={extra.name}
                      type="button"
                      onClick={() => toggleExtra(extra)}
                      className={`w-full flex items-center justify-between p-3 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'border-red-500/80 bg-red-600/10 text-white'
                          : 'border-zinc-800/80 bg-zinc-900/40 text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                            isSelected
                              ? 'border-red-500 bg-red-600 text-white'
                              : 'border-zinc-700 bg-zinc-800'
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                        <span className="text-xs font-medium text-zinc-200">{extra.name}</span>
                      </div>
                      <span className="text-xs font-bold text-amber-400 tabular-nums">
                        +Rs. {extra.price}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Kitchen Special Instructions */}
          <div className="border-t border-zinc-800/80 pt-4">
            <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2">
              Kitchen Instructions (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Extra crisp patty, sauce on side, no onions"
              className="w-full px-3.5 py-2.5 bg-zinc-900/80 border border-zinc-800 rounded-xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
            />
          </div>
        </div>

        {/* Footer with quantity and Add to Cart action */}
        <div className="p-4 sm:p-6 bg-[#0e0f14] border-t border-zinc-800 flex items-center justify-between gap-4">
          {/* Quantity stepper */}
          <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 rounded-xl p-1">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="w-8 text-center text-xs font-bold text-white tabular-nums">
              {quantity}
            </span>
            <button
              onClick={() => setQuantity(quantity + 1)}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Submit button */}
          <button
            onClick={handleConfirm}
            className="flex-1 py-3 px-5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-red-900/30 transition-all flex items-center justify-between"
          >
            <span>Add to Order</span>
            <span className="font-mono tabular-nums text-amber-300">
              Rs. {totalPrice.toLocaleString()}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
