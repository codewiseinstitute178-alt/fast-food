import React from 'react';
import { ShoppingBag, Lock, UtensilsCrossed } from 'lucide-react';

interface NavbarProps {
  activeTab: 'home' | 'menu' | 'deals' | 'tracking' | 'about' | 'admin';
  setActiveTab: (tab: 'home' | 'menu' | 'deals' | 'tracking' | 'about' | 'admin') => void;
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  cartCount,
  cartTotal,
  onOpenCart,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-[#0c0d10]/90 backdrop-blur-md border-b border-zinc-800/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 text-left group focus:outline-none"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 to-amber-600 flex items-center justify-center text-white shadow-lg shadow-red-900/30 group-hover:scale-105 transition-transform">
            <UtensilsCrossed className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xl sm:text-2xl font-bold tracking-tight text-white font-display uppercase whitespace-nowrap block leading-none">
              CRAFTSMASH<span className="text-red-500">™</span>
            </span>
            <span className="text-[10px] tracking-widest text-zinc-400 font-medium uppercase block mt-1">
              Gourmet Smash & Fast Food
            </span>
          </div>
        </button>

        {/* Zone 2: Concise single-line navigation links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
          <button
            onClick={() => setActiveTab('home')}
            className={`whitespace-nowrap transition-colors py-1 relative ${
              activeTab === 'home'
                ? 'text-red-500 font-semibold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Home
            {activeTab === 'home' && (
              <span className="absolute bottom-0 left-0 w-full h-0.5 bg-red-500 rounded-full" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('menu')}
            className={`whitespace-nowrap transition-colors py-1 relative ${
              activeTab === 'menu'
                ? 'text-red-500 font-semibold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Full Menu
            {activeTab === 'menu' && (
              <span className="absolute bottom-0 left-0 w-full h-0.5 bg-red-500 rounded-full" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('deals')}
            className={`whitespace-nowrap transition-colors py-1 relative ${
              activeTab === 'deals'
                ? 'text-red-500 font-semibold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Family Combos & Deals
            {activeTab === 'deals' && (
              <span className="absolute bottom-0 left-0 w-full h-0.5 bg-red-500 rounded-full" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('tracking')}
            className={`whitespace-nowrap transition-colors py-1 relative ${
              activeTab === 'tracking'
                ? 'text-red-500 font-semibold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Track Order
            {activeTab === 'tracking' && (
              <span className="absolute bottom-0 left-0 w-full h-0.5 bg-red-500 rounded-full" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('about')}
            className={`whitespace-nowrap transition-colors py-1 relative ${
              activeTab === 'about'
                ? 'text-red-500 font-semibold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            About & Branches
            {activeTab === 'about' && (
              <span className="absolute bottom-0 left-0 w-full h-0.5 bg-red-500 rounded-full" />
            )}
          </button>
        </nav>

        {/* Zone 3: Primary Actions (Cart + Admin shortcut) */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setActiveTab('admin')}
            title="Admin Management"
            className={`p-2.5 rounded-xl border transition-colors ${
              activeTab === 'admin'
                ? 'bg-zinc-800 text-amber-400 border-amber-500/40'
                : 'bg-zinc-900/80 border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800'
            }`}
          >
            <Lock className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenCart}
            className="flex items-center gap-3 px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-xl transition-all shadow-lg shadow-red-900/30 group"
          >
            <div className="relative">
              <ShoppingBag className="w-4 h-4" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 w-4 h-4 rounded-full bg-amber-400 text-black text-[10px] font-bold flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </div>
            <div className="hidden sm:block text-left text-xs leading-tight">
              <span className="block text-red-200 text-[10px] uppercase font-medium">Cart</span>
              <span className="font-bold tabular-nums">
                {cartTotal > 0 ? `Rs. ${cartTotal.toLocaleString()}` : 'Order Now'}
              </span>
            </div>
          </button>
        </div>
      </div>

      {/* Mobile sub-bar navigation */}
      <div className="md:hidden flex items-center justify-around px-2 py-2 border-t border-zinc-800/60 bg-[#0a0b0e] text-xs">
        <button
          onClick={() => setActiveTab('home')}
          className={`py-1 px-2.5 rounded-md ${activeTab === 'home' ? 'text-red-500 font-bold' : 'text-zinc-400'}`}
        >
          Home
        </button>
        <button
          onClick={() => setActiveTab('menu')}
          className={`py-1 px-2.5 rounded-md ${activeTab === 'menu' ? 'text-red-500 font-bold' : 'text-zinc-400'}`}
        >
          Menu
        </button>
        <button
          onClick={() => setActiveTab('deals')}
          className={`py-1 px-2.5 rounded-md ${activeTab === 'deals' ? 'text-red-500 font-bold' : 'text-zinc-400'}`}
        >
          Deals
        </button>
        <button
          onClick={() => setActiveTab('tracking')}
          className={`py-1 px-2.5 rounded-md ${activeTab === 'tracking' ? 'text-red-500 font-bold' : 'text-zinc-400'}`}
        >
          Track
        </button>
        <button
          onClick={() => setActiveTab('about')}
          className={`py-1 px-2.5 rounded-md ${activeTab === 'about' ? 'text-red-500 font-bold' : 'text-zinc-400'}`}
        >
          Branches
        </button>
      </div>
    </header>
  );
};
