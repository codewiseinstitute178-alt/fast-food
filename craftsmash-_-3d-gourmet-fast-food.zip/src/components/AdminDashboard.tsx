import React, { useState } from 'react';
import {
  Lock,
  Plus,
  Edit,
  Trash2,
  CheckCircle2,
  XCircle,
  TrendingUp,
  ShoppingBag,
  DollarSign,
  Package,
  Layers,
  Tag,
  AlertTriangle,
  LogOut,
  RefreshCw,
  Search,
} from 'lucide-react';
import { FoodItem, Order, PromoCode, FoodCategory, OrderStatus } from '../types.ts';
import { RESTAURANT_CONFIG } from '../data/initialMenu.ts';

interface AdminDashboardProps {
  foodItems: FoodItem[];
  onUpdateFoodItems: (items: FoodItem[]) => void;
  orders: Order[];
  onUpdateOrders: (orders: Order[]) => void;
  promoCodes: PromoCode[];
  onUpdatePromoCodes: (promos: PromoCode[]) => void;
  onClose: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  foodItems,
  onUpdateFoodItems,
  orders,
  onUpdateOrders,
  promoCodes,
  onUpdatePromoCodes,
  onClose,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [pinInput, setPinInput] = useState<string>('');
  const [authError, setAuthError] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'analytics' | 'orders' | 'menu' | 'promos'>('orders');

  // Menu editor modal state
  const [editingItem, setEditingItem] = useState<FoodItem | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState<boolean>(false);
  const [itemForm, setItemForm] = useState<Partial<FoodItem>>({
    name: '',
    description: '',
    price: 900,
    category: 'burgers',
    image: '',
    badge: '',
    isAvailable: true,
  });

  // Promo editor state
  const [newPromoCode, setNewPromoCode] = useState<string>('');
  const [newPromoDiscount, setNewPromoDiscount] = useState<number>(15);
  const [newPromoMin, setNewPromoMin] = useState<number>(1000);

  // Authentication check
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput === RESTAURANT_CONFIG.adminPin || pinInput === 'craftadmin') {
      setIsAuthenticated(true);
      setAuthError('');
    } else {
      setAuthError('Incorrect Admin PIN. Hint: use admin123');
    }
  };

  // Analytics calculations
  const totalRevenue = orders
    .filter((o) => o.status !== 'cancelled')
    .reduce((sum, o) => sum + o.total, 0);
  const totalOrdersCount = orders.length;
  const avgOrderValue = totalOrdersCount > 0 ? Math.round(totalRevenue / totalOrdersCount) : 0;
  const activeOrdersCount = orders.filter(
    (o) => o.status !== 'delivered' && o.status !== 'cancelled'
  ).length;

  // Order status update handler
  const handleUpdateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    const updated = orders.map((ord) => (ord.id === orderId ? { ...ord, status: newStatus } : ord));
    onUpdateOrders(updated);
  };

  // Toggle item availability
  const handleToggleItemAvailability = (itemId: string) => {
    const updated = foodItems.map((item) =>
      item.id === itemId ? { ...item, isAvailable: !item.isAvailable } : item
    );
    onUpdateFoodItems(updated);
  };

  // Delete food item confirmation state
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);

  const confirmDeleteItem = () => {
    if (itemToDelete) {
      const updated = foodItems.filter((i) => i.id !== itemToDelete);
      onUpdateFoodItems(updated);
      setItemToDelete(null);
    }
  };

  // Save Item (Create or Edit)
  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemForm.name || !itemForm.price) return;

    if (editingItem) {
      // Edit
      const updated = foodItems.map((i) =>
        i.id === editingItem.id ? ({ ...i, ...itemForm } as FoodItem) : i
      );
      onUpdateFoodItems(updated);
    } else {
      // New
      const newItem: FoodItem = {
        id: `custom-${Date.now()}`,
        name: itemForm.name || 'New Item',
        description: itemForm.description || '',
        price: Number(itemForm.price),
        category: (itemForm.category as FoodCategory) || 'burgers',
        image: itemForm.image || foodItems[0].image,
        badge: itemForm.badge,
        isAvailable: itemForm.isAvailable ?? true,
      };
      onUpdateFoodItems([newItem, ...foodItems]);
    }

    setEditingItem(null);
    setIsCreatingNew(false);
  };

  // Add promo code
  const handleAddPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPromoCode.trim()) return;

    const newPromo: PromoCode = {
      code: newPromoCode.trim().toUpperCase(),
      discountPercent: Number(newPromoDiscount),
      minOrder: Number(newPromoMin),
      description: `${newPromoDiscount}% OFF on orders over Rs. ${newPromoMin}`,
      active: true,
    };

    onUpdatePromoCodes([...promoCodes, newPromo]);
    setNewPromoCode('');
  };

  // Toggle promo active state
  const handleTogglePromo = (code: string) => {
    const updated = promoCodes.map((p) => (p.code === code ? { ...p, active: !p.active } : p));
    onUpdatePromoCodes(updated);
  };

  // Login Screen if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="py-20 bg-[#0c0d10] min-h-[75vh] flex items-center justify-center px-4">
        <div className="w-full max-w-md bg-[#14151b] border border-zinc-800 rounded-3xl p-8 shadow-2xl">
          <div className="w-12 h-12 bg-red-600/20 text-red-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Lock className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold text-center text-white font-display uppercase tracking-wide">
            Restaurant Admin Console
          </h2>
          <p className="text-xs text-center text-zinc-400 mt-1 mb-6">
            Enter administrator password PIN to manage menu, live orders, prices & analytics.
          </p>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <input
                type="password"
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                placeholder="Enter PIN (admin123)"
                className="w-full px-4 py-3 bg-zinc-900 border border-zinc-800 rounded-xl text-center text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 font-mono tracking-widest"
                autoFocus
              />
            </div>

            {authError && (
              <p className="text-xs text-red-400 text-center font-medium">{authError}</p>
            )}

            <button
              type="submit"
              className="w-full py-3 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-lg shadow-red-900/30"
            >
              Sign In to Dashboard
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-zinc-800/80 text-center">
            <span className="text-[11px] text-zinc-500">
              Demo credentials: PIN is <strong className="text-amber-400">admin123</strong>
            </span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-10 bg-[#0c0d10] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Admin Bar */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 bg-[#14151b] border border-zinc-800 rounded-3xl mb-8 shadow-xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600/20 text-red-500 flex items-center justify-center font-bold">
              CS
            </div>
            <div>
              <h1 className="text-lg font-bold text-white font-display uppercase tracking-wide">
                CraftSmash™ Kitchen & Management Dashboard
              </h1>
              <p className="text-xs text-zinc-400">
                Live branch telemetry · Active: {activeOrdersCount} orders
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAuthenticated(false)}
              className="px-3.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Log Out</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase rounded-xl transition-colors"
            >
              Back to Store
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 mb-8 overflow-x-auto pb-2">
          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2.5 text-xs font-bold uppercase tracking-wider rounded-xl transition-all ${
              activeTab === 'orders'
                ? 'bg-red-600 text-white shadow-lg shadow-red-950/40'
                : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            Live Orders ({orders.length})
          </button>
          <button
            onClick={() => setActiveTab('menu')}
            className={`px-4 py-2.5 text-xs font-bold uppercase tracking-wider rounded-xl transition-all ${
              activeTab === 'menu'
                ? 'bg-red-600 text-white shadow-lg shadow-red-950/40'
                : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            Menu Catalog & Prices ({foodItems.length})
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`px-4 py-2.5 text-xs font-bold uppercase tracking-wider rounded-xl transition-all ${
              activeTab === 'analytics'
                ? 'bg-red-600 text-white shadow-lg shadow-red-950/40'
                : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            Sales Analytics
          </button>
          <button
            onClick={() => setActiveTab('promos')}
            className={`px-4 py-2.5 text-xs font-bold uppercase tracking-wider rounded-xl transition-all ${
              activeTab === 'promos'
                ? 'bg-red-600 text-white shadow-lg shadow-red-950/40'
                : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            Vouchers & Discounts ({promoCodes.length})
          </button>
        </div>

        {/* TAB 1: ORDERS MANAGEMENT */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            {orders.length === 0 ? (
              <div className="p-12 text-center bg-[#14151b] border border-zinc-800 rounded-3xl">
                <ShoppingBag className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
                <h3 className="text-base font-bold text-white">No incoming orders</h3>
                <p className="text-xs text-zinc-500 mt-1">
                  Orders submitted by customers will appear here in real time.
                </p>
              </div>
            ) : (
              <div className="bg-[#14151b] border border-zinc-800 rounded-3xl overflow-hidden">
                <div className="p-5 border-b border-zinc-800 font-bold text-sm text-white uppercase tracking-wider">
                  Active & Completed Kitchen Orders
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#171922] text-zinc-400 uppercase tracking-wider border-b border-zinc-800">
                      <tr>
                        <th className="p-4">Order ID & Time</th>
                        <th className="p-4">Customer & Location</th>
                        <th className="p-4">Items Summary</th>
                        <th className="p-4">Total (PKR)</th>
                        <th className="p-4">Payment</th>
                        <th className="p-4">Current Status</th>
                        <th className="p-4">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800/80">
                      {orders.map((ord) => (
                        <tr key={ord.id} className="hover:bg-zinc-900/40 transition-colors">
                          <td className="p-4 font-mono font-bold text-white">
                            #{ord.id}
                            <div className="text-[10px] text-zinc-500 font-sans font-normal mt-0.5">
                              {ord.createdAt} · {ord.type}
                            </div>
                          </td>
                          <td className="p-4 text-zinc-300">
                            <div className="font-semibold text-white">{ord.customer.name}</div>
                            <div className="text-zinc-400 text-[11px]">{ord.customer.phone}</div>
                            <div className="text-zinc-500 text-[10px] truncate max-w-xs">
                              {ord.customer.address}
                            </div>
                          </td>
                          <td className="p-4 text-zinc-300">
                            <div className="space-y-0.5 max-w-xs">
                              {ord.items.map((it) => (
                                <div key={it.cartItemId} className="truncate text-[11px]">
                                  • {it.item.name} × {it.quantity}
                                </div>
                              ))}
                            </div>
                          </td>
                          <td className="p-4 font-mono font-bold text-amber-400 tabular-nums">
                            Rs. {ord.total.toLocaleString()}
                          </td>
                          <td className="p-4 uppercase text-[11px] text-zinc-400">
                            {ord.paymentMethod.replace(/_/g, ' ')}
                          </td>
                          <td className="p-4">
                            <span
                              className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase ${
                                ord.status === 'delivered'
                                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                  : ord.status === 'cancelled'
                                  ? 'bg-red-950 text-red-400 border border-red-800'
                                  : 'bg-amber-950 text-amber-400 border border-amber-800'
                              }`}
                            >
                              {ord.status.replace(/_/g, ' ')}
                            </span>
                          </td>
                          <td className="p-4">
                            <select
                              value={ord.status}
                              onChange={(e) =>
                                handleUpdateOrderStatus(ord.id, e.target.value as OrderStatus)
                              }
                              className="px-2.5 py-1.5 bg-zinc-900 border border-zinc-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500"
                            >
                              <option value="received">Received</option>
                              <option value="kitchen">Kitchen Prep</option>
                              <option value="packing">Packing</option>
                              <option value="out_for_delivery">Out for Delivery</option>
                              <option value="delivered">Delivered</option>
                              <option value="cancelled">Cancelled</option>
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: MENU CATALOG & PRICING */}
        {activeTab === 'menu' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-white uppercase tracking-wider">
                Full Restaurant Menu Items ({foodItems.length})
              </h2>
              <button
                onClick={() => {
                  setEditingItem(null);
                  setItemForm({
                    name: '',
                    description: '',
                    price: 850,
                    category: 'burgers',
                    image: foodItems[0].image,
                    badge: 'New Item',
                    isAvailable: true,
                  });
                  setIsCreatingNew(true);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add Food Item</span>
              </button>
            </div>

            {/* Menu Items Table */}
            <div className="bg-[#14151b] border border-zinc-800 rounded-3xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#171922] text-zinc-400 uppercase tracking-wider border-b border-zinc-800">
                    <tr>
                      <th className="p-4">Image</th>
                      <th className="p-4">Item Name & Category</th>
                      <th className="p-4">Price (PKR)</th>
                      <th className="p-4">Status</th>
                      <th className="p-4">Badge</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/80">
                    {foodItems.map((item) => (
                      <tr key={item.id} className="hover:bg-zinc-900/40 transition-colors">
                        <td className="p-4">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-12 h-12 rounded-xl object-cover bg-zinc-900"
                            referrerPolicy="no-referrer"
                          />
                        </td>
                        <td className="p-4 text-zinc-200">
                          <div className="font-bold text-white text-sm">{item.name}</div>
                          <div className="text-[11px] text-zinc-500 uppercase">
                            {item.category.replace('_', ' & ')}
                          </div>
                        </td>
                        <td className="p-4 font-mono font-bold text-amber-400 text-sm tabular-nums">
                          Rs. {item.price.toLocaleString()}
                        </td>
                        <td className="p-4">
                          <button
                            onClick={() => handleToggleItemAvailability(item.id)}
                            className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase transition-colors ${
                              item.isAvailable
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                : 'bg-zinc-800 text-zinc-500'
                            }`}
                          >
                            {item.isAvailable ? 'In Stock' : 'Out of Stock'}
                          </button>
                        </td>
                        <td className="p-4 text-zinc-400">
                          {item.badge ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-red-950 text-red-400 border border-red-800">
                              {item.badge}
                            </span>
                          ) : (
                            '—'
                          )}
                        </td>
                        <td className="p-4 text-right space-x-2">
                          <button
                            onClick={() => {
                              setEditingItem(item);
                              setItemForm({ ...item });
                              setIsCreatingNew(true);
                            }}
                            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300"
                            title="Edit"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setItemToDelete(item.id)}
                            className="p-1.5 rounded-lg bg-red-950/60 hover:bg-red-900 text-red-400"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Modal for Add / Edit Item */}
            {isCreatingNew && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
                <div className="w-full max-w-lg bg-[#14151b] border border-zinc-800 rounded-3xl p-6 shadow-2xl space-y-4">
                  <h3 className="text-base font-bold text-white uppercase tracking-wider">
                    {editingItem ? 'Edit Menu Item' : 'Add New Menu Item'}
                  </h3>

                  <form onSubmit={handleSaveItem} className="space-y-4 text-xs">
                    <div>
                      <label className="block text-zinc-400 mb-1">Item Title *</label>
                      <input
                        type="text"
                        required
                        value={itemForm.name || ''}
                        onChange={(e) => setItemForm({ ...itemForm, name: e.target.value })}
                        className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-zinc-400 mb-1">Description</label>
                      <textarea
                        value={itemForm.description || ''}
                        onChange={(e) =>
                          setItemForm({ ...itemForm, description: e.target.value })
                        }
                        rows={2}
                        className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-white"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-zinc-400 mb-1">Price in PKR *</label>
                        <input
                          type="number"
                          required
                          value={itemForm.price || ''}
                          onChange={(e) =>
                            setItemForm({ ...itemForm, price: parseFloat(e.target.value) })
                          }
                          className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-zinc-400 mb-1">Category</label>
                        <select
                          value={itemForm.category || 'burgers'}
                          onChange={(e) =>
                            setItemForm({
                              ...itemForm,
                              category: e.target.value as FoodCategory,
                            })
                          }
                          className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-white"
                        >
                          <option value="burgers">Burgers & Zingers</option>
                          <option value="pizza">Artisan Pizzas</option>
                          <option value="chicken">Fried Chicken</option>
                          <option value="fries">Loaded Fries</option>
                          <option value="sandwiches">Wraps & Subs</option>
                          <option value="combos">Deals & Combos</option>
                          <option value="drinks_desserts">Drinks & Desserts</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-zinc-400 mb-1">Badge (Optional)</label>
                        <input
                          type="text"
                          value={itemForm.badge || ''}
                          placeholder="e.g. Bestseller / Chef Special"
                          onChange={(e) => setItemForm({ ...itemForm, badge: e.target.value })}
                          className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-zinc-400 mb-1">Stock Availability</label>
                        <select
                          value={itemForm.isAvailable ? 'true' : 'false'}
                          onChange={(e) =>
                            setItemForm({
                              ...itemForm,
                              isAvailable: e.target.value === 'true',
                            })
                          }
                          className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-white"
                        >
                          <option value="true">In Stock</option>
                          <option value="false">Out of Stock</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-3 border-t border-zinc-800">
                      <button
                        type="button"
                        onClick={() => {
                          setIsCreatingNew(false);
                          setEditingItem(null);
                        }}
                        className="px-4 py-2 bg-zinc-800 text-zinc-300 rounded-xl"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl"
                      >
                        Save Item
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: SALES ANALYTICS */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 bg-[#14151b] border border-zinc-800 rounded-2xl">
                <div className="flex items-center justify-between text-zinc-400 mb-2">
                  <span className="text-xs font-semibold uppercase">Total Revenue</span>
                  <DollarSign className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-2xl font-bold text-white font-mono tabular-nums">
                  Rs. {totalRevenue.toLocaleString()}
                </div>
                <span className="text-[11px] text-emerald-400 mt-1 block">Live calculated</span>
              </div>

              <div className="p-5 bg-[#14151b] border border-zinc-800 rounded-2xl">
                <div className="flex items-center justify-between text-zinc-400 mb-2">
                  <span className="text-xs font-semibold uppercase">Total Orders</span>
                  <ShoppingBag className="w-4 h-4 text-red-500" />
                </div>
                <div className="text-2xl font-bold text-white font-mono tabular-nums">
                  {totalOrdersCount}
                </div>
                <span className="text-[11px] text-zinc-500 mt-1 block">Cumulative volume</span>
              </div>

              <div className="p-5 bg-[#14151b] border border-zinc-800 rounded-2xl">
                <div className="flex items-center justify-between text-zinc-400 mb-2">
                  <span className="text-xs font-semibold uppercase">Avg Order Value</span>
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-bold text-white font-mono tabular-nums">
                  Rs. {avgOrderValue.toLocaleString()}
                </div>
                <span className="text-[11px] text-zinc-500 mt-1 block">Per customer ticket</span>
              </div>

              <div className="p-5 bg-[#14151b] border border-zinc-800 rounded-2xl">
                <div className="flex items-center justify-between text-zinc-400 mb-2">
                  <span className="text-xs font-semibold uppercase">Active Kitchen Orders</span>
                  <Package className="w-4 h-4 text-orange-400" />
                </div>
                <div className="text-2xl font-bold text-amber-400 font-mono tabular-nums">
                  {activeOrdersCount}
                </div>
                <span className="text-[11px] text-zinc-500 mt-1 block">Under preparation/delivery</span>
              </div>
            </div>

            {/* Kitchen Branch Operations */}
            <div className="p-6 bg-[#14151b] border border-zinc-800 rounded-3xl">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4">
                Operational Status Across Cities
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                {RESTAURANT_CONFIG.locations.map((loc) => (
                  <div key={loc.city} className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-xl space-y-1">
                    <div className="flex items-center justify-between font-bold text-white">
                      <span>{loc.city} Kitchen</span>
                      <span className="text-emerald-400">Online 100%</span>
                    </div>
                    <p className="text-zinc-400 text-[11px]">{loc.address}</p>
                    <div className="text-amber-400 pt-1 font-mono">{loc.timing}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: VOUCHERS & PROMOS */}
        {activeTab === 'promos' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
              <h2 className="text-base font-bold text-white uppercase tracking-wider">
                Discount Vouchers & Promo Codes
              </h2>

              <form onSubmit={handleAddPromo} className="flex gap-2">
                <input
                  type="text"
                  value={newPromoCode}
                  onChange={(e) => setNewPromoCode(e.target.value)}
                  placeholder="NEW CODE (e.g. CRUNCH10)"
                  className="px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-white uppercase"
                />
                <input
                  type="number"
                  value={newPromoDiscount}
                  onChange={(e) => setNewPromoDiscount(Number(e.target.value))}
                  placeholder="% Off"
                  className="w-20 px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-white"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase rounded-xl transition-colors"
                >
                  Create
                </button>
              </form>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {promoCodes.map((promo) => (
                <div
                  key={promo.code}
                  className="p-5 bg-[#14151b] border border-zinc-800 rounded-2xl flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-base font-bold text-white font-mono tracking-wider">
                        {promo.code}
                      </span>
                      <button
                        onClick={() => handleTogglePromo(promo.code)}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          promo.active
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : 'bg-zinc-800 text-zinc-500'
                        }`}
                      >
                        {promo.active ? 'Active' : 'Disabled'}
                      </button>
                    </div>
                    <div className="text-sm font-bold text-amber-400">
                      {promo.discountPercent}% DISCOUNT
                    </div>
                    <p className="text-xs text-zinc-400 mt-1">{promo.description}</p>
                  </div>
                  <div className="text-[11px] text-zinc-500 mt-4 pt-2 border-t border-zinc-800">
                    Min order: Rs. {promo.minOrder.toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Modal for Delete Confirmation */}
        {itemToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="w-full max-w-sm bg-[#14151b] border border-zinc-800 rounded-3xl p-6 shadow-2xl space-y-4 text-center">
              <div className="w-12 h-12 rounded-2xl bg-red-600/20 text-red-500 flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white uppercase tracking-wider">
                Delete Menu Item?
              </h3>
              <p className="text-xs text-zinc-400">
                Are you sure you want to remove this item from the active menu? This action can be undone by re-adding it.
              </p>
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setItemToDelete(null)}
                  className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={confirmDeleteItem}
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase rounded-xl"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
