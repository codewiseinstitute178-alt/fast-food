import React from 'react';
import { Star, MessageSquareQuote, CheckCircle2 } from 'lucide-react';

const REVIEWS = [
  {
    id: 1,
    name: 'Daniyal Qureshi',
    role: 'Food Enthusiast',
    city: 'Lahore (Gulberg)',
    rating: 5,
    text: 'Hands down the crispiest smash burger patty in town! The Maillard crust was extraordinary, and the brioche bun held together with zero sogginess. The Cheesy Loaded Fries are pure addiction.',
    ordered: 'CraftSmash Double Truffle + Cheesy Fries',
  },
  {
    id: 2,
    name: 'Ayesha Siddiqui',
    role: 'Verified Foodie',
    city: 'Islamabad (F-7)',
    rating: 5,
    text: 'Ordered via WhatsApp and the rider arrived in 24 minutes piping hot. The wood-fired Artisan Pepperoni pizza crust had that authentic blistered char. Truly gourmet quality at reasonable prices.',
    ordered: 'Artisan Pepperoni Blaze + Nashville Tenders',
  },
  {
    id: 3,
    name: 'Hamza Farooq',
    role: 'Weekly Regular',
    city: 'Karachi (DHA)',
    rating: 5,
    text: 'The Volcano Zinger burger has the loudest crunch I have ever experienced. Huge whole chicken breast, spicy peri-peri glaze, and the molten lava cake at the end was heavenly.',
    ordered: 'Mega Family Crave Box',
  },
];

export const ReviewsSection: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-[#0c0d10] border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold tracking-wider text-amber-400 uppercase mb-2">
            <Star className="w-4 h-4 fill-amber-400" />
            <span>4.9 / 5.0 Rating from 12,000+ Bites</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold uppercase font-display text-white tracking-tight">
            WHAT OUR CRAVERS SAY
          </h2>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            Real feedback from verified foodies across Lahore, Islamabad, and Karachi.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {REVIEWS.map((rev) => (
            <div
              key={rev.id}
              className="p-6 sm:p-7 bg-[#14151b] border border-zinc-800 rounded-3xl flex flex-col justify-between hover:border-zinc-700 transition-colors"
            >
              <div>
                {/* Stars */}
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>

                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed italic mb-6">
                  "{rev.text}"
                </p>
              </div>

              <div className="pt-4 border-t border-zinc-800/80">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                      <span>{rev.name}</span>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    </h4>
                    <span className="text-[11px] text-zinc-500">{rev.city}</span>
                  </div>
                </div>
                <div className="mt-2 text-[10px] text-amber-400/90 font-medium">
                  Ordered: {rev.ordered}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
