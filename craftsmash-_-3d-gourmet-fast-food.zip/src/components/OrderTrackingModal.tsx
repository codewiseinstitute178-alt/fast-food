import React, { useState } from 'react';
import {
  Clock,
  CheckCircle2,
  ChefHat,
  Package,
  Bike,
  Phone,
  Search,
  ArrowRight,
  MapPin,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { Order, OrderStatus } from '../types.ts';

interface OrderTrackingModalProps {
  orders: Order[];
  activeOrderId?: string;
  onSelectOrder?: (orderId: string) => void;
  onAdvanceOrderStatus?: (orderId: string) => void;
  onClose?: () => void;
}

const STEPS: { status: OrderStatus; label: string; desc: string; icon: React.ElementType }[] = [
  {
    status: 'received',
    label: 'Order Confirmed',
    desc: 'Order received and verified by system.',
    icon: CheckCircle2,
  },
  {
    status: 'kitchen',
    label: 'Kitchen & Sizzling',
    desc: 'Grill masters are smashing Angus patties.',
    icon: ChefHat,
  },
  {
    status: 'packing',
    label: 'Quality Checked & Packed',
    desc: 'Sealed in thermal moisture-lock packaging.',
    icon: Package,
  },
  {
    status: 'out_for_delivery',
    label: 'Rider Out on Route',
    desc: 'Hot & fresh food en route to your doorstep.',
    icon: Bike,
  },
  {
    status: 'delivered',
    label: 'Delivered Fresh',
    desc: 'Enjoy your hot meal! Bon appétit.',
    icon: Sparkles,
  },
];

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  orders,
  activeOrderId,
  onSelectOrder,
  onAdvanceOrderStatus,
  onClose,
}) => {
  const [searchInput, setSearchInput] = useState<string>('');

  const currentOrder =
    orders.find((o) => o.id === activeOrderId) ||
    orders.find((o) => o.id.toLowerCase() === searchInput.trim().toLowerCase()) ||
    (orders.length > 0 ? orders[0] : null);

  const getStepIndex = (status: OrderStatus) => {
    switch (status) {
      case 'received':
        return 0;
      case 'kitchen':
        return 1;
      case 'packing':
        return 2;
      case 'out_for_delivery':
        return 3;
      case 'delivered':
        return 4;
      default:
        return 0;
    }
  };

  const currentStepIdx = currentOrder ? getStepIndex(currentOrder.status) : 0;

  return (
    <div className="py-12 md:py-16 bg-[#0c0d10] min-h-[70vh]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold tracking-wider text-amber-400 uppercase mb-2">
            <Clock className="w-4 h-4" />
            <span>Live Kitchen & Delivery Radar</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold uppercase font-display text-white tracking-tight">
            TRACK YOUR CRAVING
          </h2>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            Real-time stage updates from griddle to your doorstep.
          </p>
        </div>

        {/* Order Search / Quick Switcher */}
        <div className="mb-8 p-3 bg-[#14151b] border border-zinc-800 rounded-2xl flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Enter Order ID (e.g. CS-8492)..."
              className="w-full pl-10 pr-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 font-mono uppercase"
            />
          </div>

          {/* Quick chip selector of recent orders */}
          {orders.length > 0 && (
            <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto py-1">
              <span className="text-[11px] text-zinc-500 whitespace-nowrap">Recent:</span>
              {orders.slice(0, 3).map((ord) => (
                <button
                  key={ord.id}
                  onClick={() => onSelectOrder && onSelectOrder(ord.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono tabular-nums transition-colors whitespace-nowrap ${
                    currentOrder?.id === ord.id
                      ? 'bg-red-600 text-white font-bold'
                      : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                  }`}
                >
                  #{ord.id}
                </button>
              ))}
            </div>
          )}
        </div>

        {!currentOrder ? (
          <div className="p-12 text-center bg-[#14151b] border border-zinc-800 rounded-3xl">
            <Clock className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
            <h3 className="text-base font-bold text-white">No Active Orders Yet</h3>
            <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">
              Place an order from our menu to track live preparation and rider movement here.
            </p>
          </div>
        ) : (
          <div className="bg-[#14151b] border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl">
            {/* Order Meta Ribbon */}
            <div className="p-5 sm:p-6 bg-[#171922] border-b border-zinc-800 flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-zinc-400 uppercase font-medium">Order Reference:</span>
                  <span className="text-lg font-bold text-white font-mono tracking-wider">
                    #{currentOrder.id}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold uppercase bg-red-600/20 text-red-400 border border-red-500/30">
                    {currentOrder.status.replace(/_/g, ' ')}
                  </span>
                </div>
                <div className="text-xs text-zinc-400 mt-1">
                  Placed at {currentOrder.createdAt} · {currentOrder.type === 'delivery' ? 'Doorstep Delivery' : 'Self Pickup'}
                </div>
              </div>

              {/* Simulation button so users can test stage changes */}
              {onAdvanceOrderStatus && currentOrder.status !== 'delivered' && (
                <button
                  onClick={() => onAdvanceOrderStatus(currentOrder.id)}
                  className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold flex items-center gap-2 border border-zinc-700 transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
                  <span>Simulate Next Kitchen Stage</span>
                </button>
              )}
            </div>

            {/* Progress Pipeline */}
            <div className="p-6 sm:p-8 border-b border-zinc-800/80">
              <div className="relative">
                {/* Connecting track line */}
                <div className="absolute top-5 left-6 right-6 h-1 bg-zinc-800 -z-0 hidden md:block">
                  <div
                    className="h-full bg-gradient-to-r from-red-600 via-amber-500 to-emerald-500 transition-all duration-500"
                    style={{
                      width: `${(currentStepIdx / (STEPS.length - 1)) * 100}%`,
                    }}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-5 gap-6 md:gap-2 relative z-10">
                  {STEPS.map((step, idx) => {
                    const isDone = idx <= currentStepIdx;
                    const isCurrent = idx === currentStepIdx;
                    const IconComponent = step.icon;

                    return (
                      <div key={step.status} className="flex md:flex-col items-center md:text-center gap-4 md:gap-2">
                        {/* Circle node */}
                        <div
                          className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all ${
                            isCurrent
                              ? 'bg-red-600 text-white ring-4 ring-red-600/30 shadow-lg shadow-red-950 scale-110'
                              : isDone
                              ? 'bg-emerald-600 text-white'
                              : 'bg-zinc-900 border border-zinc-800 text-zinc-600'
                          }`}
                        >
                          <IconComponent className="w-5 h-5" />
                        </div>

                        {/* Text */}
                        <div>
                          <div
                            className={`text-xs font-bold uppercase tracking-wider ${
                              isCurrent ? 'text-white' : isDone ? 'text-zinc-200' : 'text-zinc-500'
                            }`}
                          >
                            {step.label}
                          </div>
                          <div className="text-[11px] text-zinc-400 mt-0.5 leading-snug">
                            {step.desc}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Rider & Delivery Details Box (if Out for delivery) */}
            {currentOrder.rider && currentOrder.type === 'delivery' && (
              <div className="p-5 sm:p-6 bg-zinc-900/50 border-b border-zinc-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                    <Bike className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[10px] text-zinc-500 uppercase font-semibold block">
                      Assigned Rider
                    </span>
                    <h4 className="text-sm font-bold text-white">{currentOrder.rider.name}</h4>
                    <p className="text-xs text-zinc-400">{currentOrder.rider.vehicle}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <div className="text-left sm:text-right">
                    <span className="text-[10px] text-zinc-500 uppercase block">Estimated ETA</span>
                    <span className="text-sm font-bold text-amber-400 tabular-nums">
                      ~{currentOrder.estimatedDeliveryMinutes} Minutes
                    </span>
                  </div>
                  <a
                    href={`tel:${currentOrder.rider.phone}`}
                    className="px-3.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-medium rounded-xl flex items-center gap-1.5 transition-colors border border-zinc-700"
                  >
                    <Phone className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Call Rider</span>
                  </a>
                </div>
              </div>
            )}

            {/* Customer Details & Receipt Breakdown */}
            <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
              {/* Destination */}
              <div className="space-y-3 bg-zinc-900/30 p-4 rounded-2xl border border-zinc-800/60">
                <h4 className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-red-500" />
                  <span>Fulfillment Address</span>
                </h4>
                <div className="text-zinc-200 font-medium">{currentOrder.customer.name}</div>
                <div className="text-zinc-400">{currentOrder.customer.phone}</div>
                <div className="text-zinc-300">{currentOrder.customer.address}</div>
                {currentOrder.customer.notes && (
                  <div className="text-amber-400/90 italic">Note: {currentOrder.customer.notes}</div>
                )}
              </div>

              {/* Items summary */}
              <div className="space-y-3 bg-zinc-900/30 p-4 rounded-2xl border border-zinc-800/60">
                <h4 className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px]">
                  Order Items ({currentOrder.items.length})
                </h4>
                <div className="space-y-1.5 max-h-36 overflow-y-auto">
                  {currentOrder.items.map((ci) => (
                    <div key={ci.cartItemId} className="flex justify-between text-zinc-300">
                      <span>
                        {ci.item.name} × {ci.quantity}
                      </span>
                      <span className="font-mono tabular-nums">Rs. {ci.totalPrice}</span>
                    </div>
                  ))}
                </div>
                <div className="pt-2 border-t border-zinc-800 flex justify-between font-bold text-white text-sm">
                  <span>Total Paid (COD/Online)</span>
                  <span className="text-amber-400 font-mono tabular-nums">
                    Rs. {currentOrder.total.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
