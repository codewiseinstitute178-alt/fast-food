import React from 'react';
import { Flame, Sparkles, ShieldCheck, Heart, MapPin, Phone, Clock } from 'lucide-react';
import { RESTAURANT_CONFIG } from '../data/initialMenu.ts';
import heroBurgerImg from '../assets/images/hero_smash_burger_1791865895211.jpg';

export const AboutSection: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-[#0a0b0e] border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Story Intro */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center mb-20">
          <div className="lg:col-span-6 space-y-6">
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-red-500 uppercase">
              <Flame className="w-4 h-4" />
              <span>The Craft Behind The Crunch</span>
            </div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold uppercase font-display text-white tracking-tight leading-tight">
              BORN ON THE GRIDDLE. <br />
              PERFECTED FOR CRAVERS.
            </h2>

            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed">
              At CraftSmash™, we believe in one simple truth: you can't fake flavor. While others pre-cook and reheat, our kitchen operates on high-heat cast iron steel.
            </p>

            <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
              We take 100% prime Angus beef, hand-season each ball with our proprietary smoked pepper blend, and smash it paper-thin against a 450°F griddle. The result is the legendary lacy Maillard crust—crisp on the edges, bursting with juice in the center.
            </p>

            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="p-4 bg-[#14151b] border border-zinc-800 rounded-2xl">
                <div className="text-amber-400 font-bold text-xl sm:text-2xl font-mono">450°F</div>
                <div className="text-xs font-semibold text-white mt-0.5">Heavy Steel Smash</div>
                <div className="text-[11px] text-zinc-400 mt-0.5">Locks in caramelized umami juices</div>
              </div>
              <div className="p-4 bg-[#14151b] border border-zinc-800 rounded-2xl">
                <div className="text-red-500 font-bold text-xl sm:text-2xl font-mono">100%</div>
                <div className="text-xs font-semibold text-white mt-0.5">Fresh Brioche Daily</div>
                <div className="text-[11px] text-zinc-400 mt-0.5">Toasted in pure creamery butter</div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 relative">
            <div className="relative rounded-3xl overflow-hidden border border-zinc-800 shadow-2xl">
              <img
                src={heroBurgerImg}
                alt="Artisanal Smash Burger Craft"
                className="w-full h-[420px] object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#121319]/80 backdrop-blur-md rounded-2xl border border-zinc-700/80">
                <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Strict Culinary Standards</span>
                </div>
                <p className="text-[11px] text-zinc-300 mt-1">
                  Zero artificial meat binders, zero frozen shortcuts, 100% certified Halal prime cuts.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Branch Locations & Hours */}
        <div>
          <div className="text-center max-w-2xl mx-auto mb-10">
            <div className="flex items-center justify-center gap-2 text-xs font-semibold tracking-wider text-amber-400 uppercase mb-2">
              <MapPin className="w-4 h-4" />
              <span>Dine-In, Takeaway & Delivery</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-bold uppercase font-display text-white">
              OUR RESTAURANT BRANCHES
            </h3>
            <p className="text-xs text-zinc-400 mt-1">
              Visit us in person or order delivery straight to your doorstep.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {RESTAURANT_CONFIG.locations.map((loc) => (
              <div
                key={loc.city}
                className="p-6 bg-[#14151b] border border-zinc-800 rounded-3xl flex flex-col justify-between hover:border-zinc-700 transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-bold text-red-500 uppercase tracking-wider">
                      {loc.city} Flagship
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-950 text-emerald-400 border border-emerald-800">
                      Open Now
                    </span>
                  </div>

                  <p className="text-xs font-medium text-white mb-3 leading-relaxed">
                    {loc.address}
                  </p>

                  <div className="space-y-2 text-xs text-zinc-400 pt-2 border-t border-zinc-800/80">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>{loc.timing}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                      <a href={`tel:${loc.phone}`} className="hover:text-white transition-colors">
                        {loc.phone}
                      </a>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-zinc-800 flex items-center justify-between">
                  <span className="text-[11px] text-zinc-500">Dine-in · Drive-thru · Takeaway</span>
                  <a
                    href={`https://maps.google.com/?q=CraftSmash+${encodeURIComponent(loc.city)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-bold text-red-400 hover:text-red-300 transition-colors"
                  >
                    View Map →
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
