import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Rotate3d, Layers, Play, Pause, Sparkles, RefreshCw, Eye } from 'lucide-react';

interface ThreeBurgerProps {
  onOrderNow?: () => void;
  className?: string;
}

export const ThreeBurger: React.FC<ThreeBurgerProps> = ({ onOrderNow, className = '' }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [explodeFactor, setExplodeFactor] = useState<number>(0);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [activeModel, setActiveModel] = useState<'burger' | 'pizza' | 'fries'>('burger');
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [hasWebGLError, setHasWebGLError] = useState<boolean>(false);

  // References for Three.js instance
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const burgerGroupRef = useRef<THREE.Group | null>(null);
  const pizzaGroupRef = useRef<THREE.Group | null>(null);
  const friesGroupRef = useRef<THREE.Group | null>(null);
  const particlesRef = useRef<THREE.Points | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  // Interactive rotation state
  const isDraggingRef = useRef<boolean>(false);
  const prevMouseRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const rotVelocityRef = useRef<{ x: number; y: number }>({ x: 0.003, y: 0 });
  const explodeTargetRef = useRef<number>(0);
  const explodeCurrentRef = useRef<number>(0);

  // Layer parts for Burger exploding
  const burgerLayersRef = useRef<{ mesh: THREE.Object3D; baseOffset: number; explodeMult: number }[]>([]);

  // Update target explode factor
  useEffect(() => {
    explodeTargetRef.current = explodeFactor;
  }, [explodeFactor]);

  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth || 500;
    const height = container.clientHeight || 500;

    // SCENE & CAMERA
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 1.2, 5.2);
    cameraRef.current = camera;

    // RENDERER
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.setSize(width, height);
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.2;
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      container.appendChild(renderer.domElement);
      rendererRef.current = renderer;
    } catch {
      setHasWebGLError(true);
      return;
    }

    // STUDIO LIGHTS
    const ambientLight = new THREE.AmbientLight(0xffeedd, 1.2);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xfff0dd, 2.5);
    keyLight.position.set(4, 6, 4);
    keyLight.castShadow = true;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xdd88ff, 0.9);
    fillLight.position.set(-4, 3, -3);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xff5533, 2.8);
    rimLight.position.set(0, -3, -4);
    scene.add(rimLight);

    // Warm underside glow light
    const underGlow = new THREE.PointLight(0xffaa33, 1.8, 10);
    underGlow.position.set(0, -2, 1);
    scene.add(underGlow);

    // ----------------------------------------------------
    // 1. PROCEDURAL 3D BURGER MODEL
    // ----------------------------------------------------
    const burgerGroup = new THREE.Group();
    burgerGroupRef.current = burgerGroup;
    scene.add(burgerGroup);

    // Materials
    const bunMaterial = new THREE.MeshStandardMaterial({
      color: 0xd9822b,
      roughness: 0.45,
      metalness: 0.05,
    });
    const toastedBunInside = new THREE.MeshStandardMaterial({
      color: 0xdeb887,
      roughness: 0.7,
    });
    const pattyMaterial = new THREE.MeshStandardMaterial({
      color: 0x3d1d11,
      roughness: 0.85,
      metalness: 0.1,
    });
    const cheeseMaterial = new THREE.MeshStandardMaterial({
      color: 0xffa000,
      roughness: 0.35,
      metalness: 0.08,
    });
    const tomatoMaterial = new THREE.MeshStandardMaterial({
      color: 0xd32f2f,
      roughness: 0.25,
      metalness: 0.1,
    });
    const lettuceMaterial = new THREE.MeshStandardMaterial({
      color: 0x4caf50,
      roughness: 0.65,
      side: THREE.DoubleSide,
    });
    const onionMaterial = new THREE.MeshStandardMaterial({
      color: 0x6d28d9,
      roughness: 0.4,
    });
    const sesameMaterial = new THREE.MeshStandardMaterial({
      color: 0xfff4db,
      roughness: 0.3,
    });

    burgerLayersRef.current = [];

    // --- Bottom Bun ---
    const bottomBun = new THREE.Mesh(
      new THREE.CylinderGeometry(1.22, 1.1, 0.32, 32),
      [bunMaterial, toastedBunInside, bunMaterial]
    );
    bottomBun.position.y = -0.7;
    burgerGroup.add(bottomBun);
    burgerLayersRef.current.push({ mesh: bottomBun, baseOffset: -0.7, explodeMult: -1.2 });

    // --- Bottom Lettuce (Ruffled) ---
    const lettuceMesh = new THREE.Group();
    for (let i = 0; i < 7; i++) {
      const angle = (i / 7) * Math.PI * 2;
      const leaf = new THREE.Mesh(
        new THREE.CylinderGeometry(0.35, 0.45, 0.04, 8),
        lettuceMaterial
      );
      leaf.position.set(Math.cos(angle) * 1.05, 0, Math.sin(angle) * 1.05);
      leaf.rotation.z = (Math.random() - 0.5) * 0.4;
      leaf.rotation.y = angle;
      lettuceMesh.add(leaf);
    }
    const centerLeaf = new THREE.Mesh(new THREE.CylinderGeometry(1.28, 1.25, 0.05, 24), lettuceMaterial);
    lettuceMesh.add(centerLeaf);
    lettuceMesh.position.y = -0.48;
    burgerGroup.add(lettuceMesh);
    burgerLayersRef.current.push({ mesh: lettuceMesh, baseOffset: -0.48, explodeMult: -0.7 });

    // --- Patty 1 (Smash Patty) ---
    const patty1 = new THREE.Mesh(new THREE.CylinderGeometry(1.28, 1.3, 0.26, 32), pattyMaterial);
    patty1.position.y = -0.3;
    burgerGroup.add(patty1);
    burgerLayersRef.current.push({ mesh: patty1, baseOffset: -0.3, explodeMult: -0.3 });

    // --- Melted Cheese 1 ---
    const cheese1 = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.05, 1.7), cheeseMaterial);
    cheese1.rotation.y = Math.PI / 4;
    cheese1.position.y = -0.14;
    burgerGroup.add(cheese1);
    burgerLayersRef.current.push({ mesh: cheese1, baseOffset: -0.14, explodeMult: 0.1 });

    // --- Sliced Tomatoes (2 round discs) ---
    const tomatoGroup = new THREE.Group();
    const tom1 = new THREE.Mesh(new THREE.CylinderGeometry(0.68, 0.68, 0.1, 24), tomatoMaterial);
    tom1.position.set(-0.4, 0, 0.2);
    const tom2 = new THREE.Mesh(new THREE.CylinderGeometry(0.68, 0.68, 0.1, 24), tomatoMaterial);
    tom2.position.set(0.42, 0, -0.2);
    tomatoGroup.add(tom1, tom2);
    tomatoGroup.position.y = 0.02;
    burgerGroup.add(tomatoGroup);
    burgerLayersRef.current.push({ mesh: tomatoGroup, baseOffset: 0.02, explodeMult: 0.5 });

    // --- Patty 2 (Upper Smash Patty) ---
    const patty2 = new THREE.Mesh(new THREE.CylinderGeometry(1.26, 1.28, 0.26, 32), pattyMaterial);
    patty2.position.y = 0.24;
    burgerGroup.add(patty2);
    burgerLayersRef.current.push({ mesh: patty2, baseOffset: 0.24, explodeMult: 0.9 });

    // --- Melted Cheddar 2 ---
    const cheese2 = new THREE.Mesh(new THREE.BoxGeometry(1.65, 0.05, 1.65), cheeseMaterial);
    cheese2.rotation.y = 0.3;
    cheese2.position.y = 0.4;
    burgerGroup.add(cheese2);
    burgerLayersRef.current.push({ mesh: cheese2, baseOffset: 0.4, explodeMult: 1.3 });

    // --- Caramelized Onion Rings ---
    const onionGroup = new THREE.Group();
    for (let i = 0; i < 4; i++) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.4 + i * 0.18, 0.04, 8, 20), onionMaterial);
      ring.rotation.x = Math.PI / 2;
      ring.position.set((Math.random() - 0.5) * 0.3, i * 0.02, (Math.random() - 0.5) * 0.3);
      onionGroup.add(ring);
    }
    onionGroup.position.y = 0.48;
    burgerGroup.add(onionGroup);
    burgerLayersRef.current.push({ mesh: onionGroup, baseOffset: 0.48, explodeMult: 1.6 });

    // --- Top Bun (Dome + Sesame Seeds) ---
    const topBunGroup = new THREE.Group();
    const domeGeom = new THREE.SphereGeometry(1.3, 32, 16, 0, Math.PI * 2, 0, Math.PI * 0.5);
    const domeMesh = new THREE.Mesh(domeGeom, bunMaterial);
    topBunGroup.add(domeMesh);

    // Sprinkle 35 sesame seeds on top bun
    const sesameGeom = new THREE.SphereGeometry(0.03, 6, 6);
    sesameGeom.scale(1, 0.4, 1.8);
    for (let i = 0; i < 45; i++) {
      const u = Math.random();
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(u) * 0.85; // Upper half dome
      const r = 1.31;
      const x = r * Math.sin(phi) * Math.cos(theta);
      const y = r * Math.cos(phi);
      const z = r * Math.sin(phi) * Math.sin(theta);

      const seed = new THREE.Mesh(sesameGeom, sesameMaterial);
      seed.position.set(x, y, z);
      seed.lookAt(x * 2, y * 2, z * 2);
      topBunGroup.add(seed);
    }
    topBunGroup.position.y = 0.55;
    burgerGroup.add(topBunGroup);
    burgerLayersRef.current.push({ mesh: topBunGroup, baseOffset: 0.55, explodeMult: 2.2 });

    // ----------------------------------------------------
    // 2. PROCEDURAL 3D PIZZA MODEL
    // ----------------------------------------------------
    const pizzaGroup = new THREE.Group();
    pizzaGroupRef.current = pizzaGroup;
    pizzaGroup.visible = false;
    scene.add(pizzaGroup);

    const crustMat = new THREE.MeshStandardMaterial({ color: 0xc97a2b, roughness: 0.6 });
    const pizzaBase = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.6, 0.12, 32), cheeseMaterial);
    const crustRing = new THREE.Mesh(new THREE.TorusGeometry(1.6, 0.18, 12, 36), crustMat);
    crustRing.rotation.x = Math.PI / 2;
    pizzaGroup.add(pizzaBase, crustRing);

    // Pepperoni slices
    const pepMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.3 });
    const pepGeom = new THREE.CylinderGeometry(0.24, 0.24, 0.04, 16);
    for (let i = 0; i < 14; i++) {
      const dist = 0.3 + Math.random() * 1.0;
      const ang = Math.random() * Math.PI * 2;
      const pep = new THREE.Mesh(pepGeom, pepMat);
      pep.position.set(Math.cos(ang) * dist, 0.08, Math.sin(ang) * dist);
      pizzaGroup.add(pep);
    }
    // Basil leaves
    const basilMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.4 });
    for (let i = 0; i < 6; i++) {
      const bLeaf = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.02, 0.14), basilMat);
      bLeaf.position.set((Math.random() - 0.5) * 1.8, 0.09, (Math.random() - 0.5) * 1.8);
      bLeaf.rotation.y = Math.random() * Math.PI;
      pizzaGroup.add(bLeaf);
    }
    pizzaGroup.rotation.x = 0.5;

    // ----------------------------------------------------
    // 3. PROCEDURAL 3D FRIES MODEL
    // ----------------------------------------------------
    const friesGroup = new THREE.Group();
    friesGroupRef.current = friesGroup;
    friesGroup.visible = false;
    scene.add(friesGroup);

    // Red carton
    const cartonMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.3 });
    const carton = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.65, 1.6, 16), cartonMat);
    friesGroup.add(carton);

    // Fry sticks
    const fryMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.5 });
    const fryGeom = new THREE.BoxGeometry(0.12, 1.4, 0.12);
    for (let i = 0; i < 28; i++) {
      const fry = new THREE.Mesh(fryGeom, fryMat);
      const angle = (i / 28) * Math.PI * 2;
      const rad = Math.random() * 0.55;
      fry.position.set(Math.cos(angle) * rad, 0.7 + Math.random() * 0.4, Math.sin(angle) * rad);
      fry.rotation.set((Math.random() - 0.5) * 0.3, Math.random() * Math.PI, (Math.random() - 0.5) * 0.3);
      friesGroup.add(fry);
    }

    // ----------------------------------------------------
    // 4. FLOATING SIZZLE STEAM PARTICLES
    // ----------------------------------------------------
    const particleCount = 50;
    const particleGeom = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount * 3; i += 3) {
      particlePositions[i] = (Math.random() - 0.5) * 2.5;
      particlePositions[i + 1] = Math.random() * 2.5 - 0.5;
      particlePositions[i + 2] = (Math.random() - 0.5) * 2.5;
    }
    particleGeom.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0xffaa55,
      size: 0.05,
      transparent: true,
      opacity: 0.45,
      blending: THREE.AdditiveBlending,
    });
    const particles = new THREE.Points(particleGeom, particleMat);
    scene.add(particles);
    particlesRef.current = particles;

    // ----------------------------------------------------
    // ANIMATION & INTERACTION LOOP
    // ----------------------------------------------------
    let clock = new THREE.Clock();

    const animate = () => {
      animFrameIdRef.current = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const elapsed = clock.getElapsedTime();

      // Smoothly interpolate explode value
      explodeCurrentRef.current += (explodeTargetRef.current - explodeCurrentRef.current) * 0.08;
      const curExplode = explodeCurrentRef.current;

      // Update burger layer offsets
      burgerLayersRef.current.forEach(({ mesh, baseOffset, explodeMult }) => {
        mesh.position.y = baseOffset + curExplode * explodeMult * 0.85;
      });

      // Active Model Visibility & Subtle Float
      if (burgerGroupRef.current) {
        burgerGroupRef.current.visible = activeModel === 'burger';
        if (activeModel === 'burger') {
          burgerGroupRef.current.position.y = Math.sin(elapsed * 1.5) * 0.08;
        }
      }
      if (pizzaGroupRef.current) {
        pizzaGroupRef.current.visible = activeModel === 'pizza';
        if (activeModel === 'pizza') {
          pizzaGroupRef.current.position.y = Math.sin(elapsed * 1.5) * 0.08;
        }
      }
      if (friesGroupRef.current) {
        friesGroupRef.current.visible = activeModel === 'fries';
        if (activeModel === 'fries') {
          friesGroupRef.current.position.y = Math.sin(elapsed * 1.5) * 0.08;
        }
      }

      // Rotate active group
      const targetGroup =
        activeModel === 'burger'
          ? burgerGroupRef.current
          : activeModel === 'pizza'
          ? pizzaGroupRef.current
          : friesGroupRef.current;

      if (targetGroup) {
        if (!isDraggingRef.current && autoRotate) {
          targetGroup.rotation.y += 0.008;
        } else if (!isDraggingRef.current) {
          // Inertial damping
          targetGroup.rotation.y += rotVelocityRef.current.x;
          rotVelocityRef.current.x *= 0.94;
        }
      }

      // Animate floating steam particles
      if (particlesRef.current) {
        const pos = particlesRef.current.geometry.attributes.position.array as Float32Array;
        for (let i = 1; i < pos.length; i += 3) {
          pos[i] += delta * 0.6; // ascend
          if (pos[i] > 2.6) {
            pos[i] = -0.5;
            pos[i - 1] = (Math.random() - 0.5) * 2;
            pos[i + 1] = (Math.random() - 0.5) * 2;
          }
        }
        particlesRef.current.geometry.attributes.position.needsUpdate = true;
        particlesRef.current.rotation.y = elapsed * 0.08;
      }

      renderer.render(scene, camera);
    };

    animate();

    // RESIZE LISTENER
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const newW = container.clientWidth;
      const newH = container.clientHeight;
      cameraRef.current.aspect = newW / newH;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(newW, newH);
    };
    window.addEventListener('resize', handleResize);

    // CLEANUP
    return () => {
      window.removeEventListener('resize', handleResize);
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
      if (rendererRef.current && rendererRef.current.domElement) {
        rendererRef.current.domElement.remove();
        rendererRef.current.dispose();
      }
    };
  }, [activeModel, autoRotate]);

  // Pointer drag to orbit 3D model
  const handlePointerDown = (e: React.PointerEvent) => {
    isDraggingRef.current = true;
    prevMouseRef.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDraggingRef.current) return;
    const deltaX = e.clientX - prevMouseRef.current.x;
    const deltaY = e.clientY - prevMouseRef.current.y;
    prevMouseRef.current = { x: e.clientX, y: e.clientY };

    const targetGroup =
      activeModel === 'burger'
        ? burgerGroupRef.current
        : activeModel === 'pizza'
        ? pizzaGroupRef.current
        : friesGroupRef.current;

    if (targetGroup) {
      targetGroup.rotation.y += deltaX * 0.008;
      targetGroup.rotation.x = Math.max(-0.6, Math.min(0.6, targetGroup.rotation.x + deltaY * 0.005));
      rotVelocityRef.current = { x: deltaX * 0.005, y: deltaY * 0.003 };
    }
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
  };

  const resetView = () => {
    const targetGroup =
      activeModel === 'burger'
        ? burgerGroupRef.current
        : activeModel === 'pizza'
        ? pizzaGroupRef.current
        : friesGroupRef.current;
    if (targetGroup) {
      targetGroup.rotation.set(activeModel === 'pizza' ? 0.5 : 0, 0, 0);
    }
    setExplodeFactor(0);
  };

  return (
    <div
      className={`relative w-full h-[520px] md:h-[620px] rounded-3xl overflow-hidden bg-gradient-to-b from-[#14151b] via-[#0f1015] to-[#0c0d10] border border-zinc-800/80 shadow-2xl flex flex-col ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Background ambient lighting aura */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-red-600/15 rounded-full blur-[100px]" />
        <div className="absolute bottom-10 right-1/4 w-72 h-72 bg-amber-500/15 rounded-full blur-[90px]" />
      </div>

      {/* Top 3D Mode Selector & Badges */}
      <div className="relative z-20 flex items-center justify-between p-4 md:p-6 border-b border-zinc-800/60 bg-[#0c0d10]/40 backdrop-blur-md">
        <div className="flex items-center gap-1.5 p-1 bg-zinc-900/90 border border-zinc-800 rounded-xl">
          <button
            onClick={() => {
              setActiveModel('burger');
              setExplodeFactor(0);
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeModel === 'burger'
                ? 'bg-red-600 text-white shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            3D Smash Burger
          </button>
          <button
            onClick={() => {
              setActiveModel('pizza');
              setExplodeFactor(0);
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeModel === 'pizza'
                ? 'bg-red-600 text-white shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            3D Artisan Pizza
          </button>
          <button
            onClick={() => {
              setActiveModel('fries');
              setExplodeFactor(0);
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeModel === 'fries'
                ? 'bg-red-600 text-white shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            3D Loaded Fries
          </button>
        </div>

        {/* Status / Instruction text */}
        <div className="hidden sm:flex items-center gap-2 text-xs text-zinc-400">
          <Rotate3d className="w-3.5 h-3.5 text-amber-500 animate-spin" style={{ animationDuration: '6s' }} />
          <span>Drag to orbit 360°</span>
        </div>
      </div>

      {/* 3D WebGL Canvas or Fallback */}
      <div
        ref={mountRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        className="relative flex-1 w-full cursor-grab active:cursor-grabbing touch-none select-none"
      >
        {hasWebGLError && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
            <p className="text-sm text-zinc-400">3D acceleration is in low power mode.</p>
          </div>
        )}

        {/* Dynamic Exploded Layer Labels Overlay (Burger mode only when exploded) */}
        {activeModel === 'burger' && explodeFactor > 0.35 && (
          <div className="absolute inset-y-8 left-4 md:left-8 flex flex-col justify-between pointer-events-none text-left z-20 transition-opacity duration-300">
            <div className="bg-black/70 backdrop-blur-md px-3 py-1 rounded-md border border-amber-500/30 text-xs font-medium text-amber-300">
              01. Golden Brioche Bun + Sesame
            </div>
            <div className="bg-black/70 backdrop-blur-md px-3 py-1 rounded-md border border-amber-500/30 text-xs font-medium text-amber-200">
              02. Melted Wisconsin Cheddar
            </div>
            <div className="bg-black/70 backdrop-blur-md px-3 py-1 rounded-md border border-red-500/30 text-xs font-medium text-red-300">
              03. 100% Angus Smash Patty (Sear-Crusted)
            </div>
            <div className="bg-black/70 backdrop-blur-md px-3 py-1 rounded-md border border-red-500/30 text-xs font-medium text-red-300">
              04. Vine-Ripe Red Tomatoes & Pickles
            </div>
            <div className="bg-black/70 backdrop-blur-md px-3 py-1 rounded-md border border-emerald-500/30 text-xs font-medium text-emerald-300">
              05. Crisp Butterhead Lettuce & Secret Aioli
            </div>
            <div className="bg-black/70 backdrop-blur-md px-3 py-1 rounded-md border border-amber-500/30 text-xs font-medium text-amber-300">
              06. Toasted Brioche Base
            </div>
          </div>
        )}
      </div>

      {/* Floating 3D Controls HUD Bar */}
      <div className="relative z-20 p-4 md:px-6 md:py-4 bg-[#0c0d10]/80 backdrop-blur-md border-t border-zinc-800/80 flex flex-wrap items-center justify-between gap-4">
        {/* Left: Explode Layer Slider (Burger Only) */}
        {activeModel === 'burger' ? (
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="flex items-center gap-1.5 text-xs font-medium text-zinc-300">
              <Layers className="w-3.5 h-3.5 text-red-500" />
              Layers:
            </span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={explodeFactor}
              onChange={(e) => setExplodeFactor(parseFloat(e.target.value))}
              className="w-24 md:w-32 accent-red-500 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
            />
            <span className="text-xs font-mono text-zinc-400 tabular-nums">
              {Math.round(explodeFactor * 100)}%
            </span>

            {/* Quick Presets */}
            <div className="flex items-center gap-1 ml-1">
              <button
                type="button"
                onClick={() => setExplodeFactor(0)}
                className={`px-2 py-0.5 rounded text-[10px] font-semibold transition-colors ${
                  explodeFactor === 0
                    ? 'bg-red-600 text-white'
                    : 'bg-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                Assemble
              </button>
              <button
                type="button"
                onClick={() => setExplodeFactor(0.75)}
                className={`px-2 py-0.5 rounded text-[10px] font-semibold transition-colors ${
                  explodeFactor > 0.4
                    ? 'bg-red-600 text-white'
                    : 'bg-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                Explode
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-xs text-zinc-400">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Real-time physically lit 3D preview</span>
          </div>
        )}

        {/* Right Action buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setAutoRotate(!autoRotate)}
            title={autoRotate ? 'Pause Rotation' : 'Auto Rotate'}
            className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            {autoRotate ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
          <button
            onClick={resetView}
            title="Reset 3D Orientation"
            className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          {onOrderNow && (
            <button
              onClick={onOrderNow}
              className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-semibold text-xs rounded-lg transition-all shadow-lg shadow-red-900/30 flex items-center gap-1.5 ml-2"
            >
              Order This Now
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
