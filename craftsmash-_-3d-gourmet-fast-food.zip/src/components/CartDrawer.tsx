import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ArrowRight, Tag, ShoppingBag, ShieldCheck } from 'lucide-react';
import { CartItem, PromoCode } from '../types.ts';
import { RESTAURANT_CONFIG } from '../data/initialMenu.ts';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (cartItemId: string, newQuantity: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onProceedToCheckout: () => void;
  appliedPromo: PromoCode | null;
  onApplyPromo: (code: string) => boolean;
  onRemovePromo: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
  appliedPromo,
  onApplyPromo,
  onRemovePromo,
}) => {
  const [promoInput, setPromoInput] = useState<string>('');
  const [promoError, setPromoError] = useState<string>('');

  if (!isOpen) return null;

  // Financial calculations
  const subtotal = items.reduce((sum, item) => sum + item.totalPrice, 0);
  const deliveryFee = subtotal >= RESTAURANT_CONFIG.freeDeliveryThreshold || items.length === 0 ? 0 : RESTAURANT_CONFIG.deliveryFee;
  const discountAmount = appliedPromo ? Math.round((subtotal * appliedPromo.discountPercent) / 100) : 0;
  const grandTotal = Math.max(0, subtotal + deliveryFee - discountAmount);

  const handleApplyPromoCode = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError('');
    if (!promoInput.trim()) return;

    const success = onApplyPromo(promoInput.trim().toUpperCase());
    if (!success) {
      setPromoError('Invalid or inactive promo code (Try SMASH20 or FIRSTBITE)');
    } else {
      setPromoInput('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
      />

      {/* Slide-over Container */}
      <div className="relative w-full max-w-md bg-[#121319] border-l border-zinc-800 h-full flex flex-col z-10 shadow-2xl">
        {/* Header */}
        <div className="p-5 border-b border-zinc-800/80 flex items-center justify-between bg-[#14151c]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-red-600/20 text-red-500 rounded-xl">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white font-display uppercase tracking-wide">
                Your Crave Basket
              </h2>
              <span className="text-xs text-zinc-400">
                {items.length} {items.length === 1 ? 'item' : 'items'} selected
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Delivery Progress Bar */}
        {subtotal > 0 && subtotal < RESTAURANT_CONFIG.freeDeliveryThreshold && (
          <div className="px-5 py-2.5 bg-zinc-900/80 border-b border-zinc-800/60 text-xs">
            <div className="flex justify-between text-zinc-300 mb-1">
              <span>Add Rs. {RESTAURANT_CONFIG.freeDeliveryThreshold - subtotal} more for</span>
              <span className="font-semibold text-amber-400">FREE DELIVERY</span>
            </div>
            <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-amber-400 h-full transition-all duration-300"
                style={{
                  width: `${Math.min(100, (subtotal / RESTAURANT_CONFIG.freeDeliveryThreshold) * 100)}%`,
                }}
              />
            </div>
          </div>
        )}

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-zinc-400">
              <ShoppingBag className="w-12 h-12 text-zinc-700 mb-3" />
              <p className="text-base font-semibold text-zinc-300">Your basket is empty</p>
              <p className="text-xs text-zinc-500 mt-1 max-w-xs">
                Explore our sizzling burgers, artisan pizzas, or loaded fries and add your favorites.
              </p>
              <button
                onClick={onClose}
                className="mt-5 px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase rounded-xl transition-colors"
              >
                Browse Menu
              </button>
            </div>
          ) : (
            items.map((cartItem) => (
              <div
                key={cartItem.cartItemId}
                className="p-3.5 bg-[#171922] border border-zinc-800/80 rounded-2xl flex gap-3 items-start"
              >
                <img
                  src={cartItem.item.image}
                  alt={cartItem.item.name}
                  className="w-16 h-16 rounded-xl object-cover bg-zinc-900 shrink-0"
                  referrerPolicy="no-referrer"
                />

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wide truncate">
                      {cartItem.item.name}
                    </h4>
                    <button
                      onClick={() => onRemoveItem(cartItem.cartItemId)}
                      className="text-zinc-500 hover:text-red-400 p-1"
                      title="Remove"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Size and custom extras */}
                  {cartItem.selectedSize && (
                    <div className="text-[11px] text-amber-400 font-medium">
                      Size: {cartItem.selectedSize}
                    </div>
                  )}

                  {cartItem.selectedExtras && cartItem.selectedExtras.length > 0 && (
                    <div className="text-[10px] text-zinc-400 line-clamp-1 mt-0.5">
                      + {cartItem.selectedExtras.map((e) => e.name).join(', ')}
                    </div>
                  )}

                  {cartItem.notes && (
                    <div className="text-[10px] text-zinc-500 italic mt-0.5 truncate">
                      Note: {cartItem.notes}
                    </div>
                  )}

                  {/* Price and Stepper */}
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-xs font-bold text-white font-mono tabular-nums">
                      Rs. {cartItem.totalPrice.toLocaleString()}
                    </span>

                    <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 rounded-lg p-0.5">
                      <button
                        onClick={() => onUpdateQuantity(cartItem.cartItemId, cartItem.quantity - 1)}
                        className="p-1 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-5 text-center text-xs font-bold text-white tabular-nums">
                        {cartItem.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(cartItem.cartItemId, cartItem.quantity + 1)}
                        className="p-1 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Summary & Checkout */}
        {items.length > 0 && (
          <div className="p-5 bg-[#14151c] border-t border-zinc-800/80 space-y-4">
            {/* Promo Code Input */}
            <div>
              {appliedPromo ? (
                <div className="flex items-center justify-between p-2.5 bg-emerald-950/40 border border-emerald-800/60 rounded-xl text-xs text-emerald-300">
                  <div className="flex items-center gap-2">
                    <Tag className="w-3.5 h-3.5 text-emerald-400" />
                    <span>
                      Voucher <strong>{appliedPromo.code}</strong> applied ({appliedPromo.discountPercent}% OFF)
                    </span>
                  </div>
                  <button
                    onClick={onRemovePromo}
                    className="text-zinc-400 hover:text-white underline text-[11px]"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <form onSubmit={handleApplyPromoCode} className="flex gap-2">
                    <input
                      type="text"
                      value={promoInput}
                      onChange={(e) => setPromoInput(e.target.value)}
                      placeholder="Enter voucher (e.g. SMASH20)"
                      className="flex-1 px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-white uppercase placeholder-zinc-500 focus:outline-none focus:border-red-500"
                    />
                    <button
                      type="submit"
                      className="px-3.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold rounded-xl transition-colors"
                    >
                      Apply
                    </button>
                  </form>
                  <div className="flex items-center gap-1.5 text-[11px] text-zinc-400">
                    <span className="text-zinc-500">Available:</span>
                    <button
                      type="button"
                      onClick={() => onApplyPromo('SMASH20')}
                      className="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-amber-300 font-mono font-bold transition-colors"
                    >
                      SMASH20 (-20%)
                    </button>
                    <button
                      type="button"
                      onClick={() => onApplyPromo('FIRSTBITE')}
                      className="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-amber-300 font-mono font-bold transition-colors"
                    >
                      FIRSTBITE (-15%)
                    </button>
                  </div>
                </div>
              )}
              {promoError && (
                <p className="text-[11px] text-red-400 mt-1">{promoError}</p>
              )}
            </div>

            {/* Calculations Breakdown */}
            <div className="space-y-1.5 text-xs text-zinc-400 pt-1">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="text-zinc-200 font-mono tabular-nums">
                  Rs. {subtotal.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Charge</span>
                <span className="text-zinc-200 font-mono tabular-nums">
                  {deliveryFee === 0 ? (
                    <span className="text-emerald-400 font-semibold">FREE</span>
                  ) : (
                    `Rs. ${deliveryFee}`
                  )}
                </span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Discount</span>
                  <span className="font-mono tabular-nums">-Rs. {discountAmount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-zinc-800">
                <span>Total Amount</span>
                <span className="text-amber-400 font-mono tabular-nums text-base">
                  Rs. {grandTotal.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Checkout Action */}
            <button
              onClick={() => {
                onClose();
                onProceedToCheckout();
              }}
              className="w-full py-3.5 px-4 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-red-900/40 transition-all flex items-center justify-center gap-2"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
