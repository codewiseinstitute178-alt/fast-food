import React from 'react';
import { UtensilsCrossed, MessageCircle, Phone, MapPin, Clock, ShieldCheck } from 'lucide-react';
import { RESTAURANT_CONFIG } from '../data/initialMenu.ts';

interface FooterProps {
  onNavigateTab: (tab: 'home' | 'menu' | 'deals' | 'tracking' | 'about' | 'admin') => void;
  onOpenWhatsApp: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigateTab, onOpenWhatsApp }) => {
  return (
    <footer className="bg-[#090a0d] border-t border-zinc-900 text-zinc-400 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-zinc-800/80">
          {/* Brand Info */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-red-600 to-amber-600 flex items-center justify-center text-white shadow-lg">
                <UtensilsCrossed className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold font-display uppercase tracking-tight text-white">
                CRAFTSMASH<span className="text-red-500">™</span> GOURMET
              </span>
            </div>

            <p className="text-xs sm:text-sm text-zinc-400 max-w-sm leading-relaxed">
              Premium 3D fast food culinary craftsmanship. Artisanal double smash burgers, wood-fired blistered pizzas, golden southern fried chicken, and loaded cheesy fries.
            </p>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={onOpenWhatsApp}
                className="px-4 py-2 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-400 border border-emerald-800/70 text-xs font-semibold flex items-center gap-2 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp Ordering</span>
              </button>
              <a
                href={`tel:${RESTAURANT_CONFIG.phone}`}
                className="px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 text-xs font-semibold flex items-center gap-2 transition-colors"
              >
                <Phone className="w-4 h-4 text-amber-500" />
                <span>{RESTAURANT_CONFIG.phone}</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Explore Our Food
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigateTab('menu')}
                  className="hover:text-white transition-colors"
                >
                  Burgers & Zinger Combos
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('menu')}
                  className="hover:text-white transition-colors"
                >
                  Wood-Fired Artisan Pizzas
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('menu')}
                  className="hover:text-white transition-colors"
                >
                  Southern Crispy Chicken & Tenders
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('deals')}
                  className="hover:text-white transition-colors"
                >
                  Family Bundles & Midnight Boxes
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('tracking')}
                  className="hover:text-white transition-colors"
                >
                  Live Order Tracker
                </button>
              </li>
            </ul>
          </div>

          {/* Cities & Flagships */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Flagship Kitchens
            </h4>
            <div className="space-y-3 text-xs">
              <div>
                <span className="font-semibold text-white block">Lahore (Gulberg III)</span>
                <span className="text-[11px] text-zinc-500 block">
                  Main Boulevard, Gulberg III · Open till 03:30 AM
                </span>
              </div>
              <div>
                <span className="font-semibold text-white block">Islamabad (F-7 Markaz)</span>
                <span className="text-[11px] text-zinc-500 block">
                  Beverly Centre, Blue Area · Open till 03:00 AM
                </span>
              </div>
              <div>
                <span className="font-semibold text-white block">Karachi (DHA Phase 6)</span>
                <span className="text-[11px] text-zinc-500 block">
                  Khayaban-e-Shahbaz · Open till 04:00 AM
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <div>
            © {new Date().getFullYear()} CraftSmash™ Gourmet Restaurant. All rights reserved. 100% Halal Certified.
          </div>
          <div className="flex items-center gap-6">
            <button
              onClick={() => onNavigateTab('about')}
              className="hover:text-zinc-300 transition-colors"
            >
              Privacy & Hygiene
            </button>
            <button
              onClick={() => onNavigateTab('about')}
              className="hover:text-zinc-300 transition-colors"
            >
              Terms of Service
            </button>
            <button
              onClick={() => onNavigateTab('admin')}
              className="text-amber-500/80 hover:text-amber-400 transition-colors"
            >
              Admin Console
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
