import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  X,
  Send,
  Sparkles,
  Bot,
  User,
  ShoppingBag,
  Flame,
  Tag,
  ChevronDown,
  RotateCcw,
} from 'lucide-react';
import { FoodItem } from '../types.ts';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  suggestedAction?: {
    type: 'add_to_cart' | 'open_menu' | 'open_deals' | 'track_order';
    label: string;
    itemId?: string;
  };
}

interface AIAgentChatbotProps {
  onQuickAddFoodItem?: (item: FoodItem) => void;
  onNavigateTab?: (tab: 'home' | 'menu' | 'deals' | 'tracking' | 'about') => void;
  availableFoodItems: FoodItem[];
}

const QUICK_PROMPTS = [
  '🔥 What is your spiciest burger?',
  '🍕 Best combo deal for 2 people?',
  '🎟️ Any active discount codes?',
  '📍 What are your branch locations?',
];

export const AIAgentChatbot: React.FC<AIAgentChatbotProps> = ({
  onQuickAddFoodItem,
  onNavigateTab,
  availableFoodItems,
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [inputMessage, setInputMessage] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-1',
      role: 'assistant',
      content:
        "Hey foodie! 👋 I'm **Chef Smash**, your personal AI food concierge. Looking for our crispiest burger, a mega pizza deal, or today's top discount voucher?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      inputRef.current?.focus();
    }
  }, [messages, isOpen]);

  const sendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text || isLoading) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userMessage: text,
          messages: [...messages, userMsg],
        }),
      });

      const data = await response.json();
      const botReply =
        data.reply ||
        data.fallback ||
        "I'm here to help you crave! Try our Double Truffle Burger or use promo code SMASH20.";

      // Determine smart suggested action based on content
      let suggestedAction: Message['suggestedAction'] = undefined;
      const lower = text.toLowerCase() + ' ' + botReply.toLowerCase();
      if (lower.includes('volcano') || lower.includes('spiciest')) {
        const volcanoItem = availableFoodItems.find((i) => i.id === 'b-2');
        if (volcanoItem) {
          suggestedAction = {
            type: 'add_to_cart',
            label: 'Add Volcano Zinger (Rs. 790)',
            itemId: 'b-2',
          };
        }
      } else if (lower.includes('truffle') || lower.includes('double smash')) {
        const truffleItem = availableFoodItems.find((i) => i.id === 'b-1');
        if (truffleItem) {
          suggestedAction = {
            type: 'add_to_cart',
            label: 'Add Double Truffle (Rs. 1,050)',
            itemId: 'b-1',
          };
        }
      } else if (lower.includes('deal') || lower.includes('combo')) {
        suggestedAction = {
          type: 'open_deals',
          label: 'View Family Combos & Deals',
        };
      }

      const botMsg: Message = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: botReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedAction,
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch {
      const errorMsg: Message = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content:
          "I'm temporarily cooking in the griddle room! But I highly recommend our **Double Truffle Burger** (Rs. 1,050) and our voucher **SMASH20** for 20% off!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleActionClick = (action: Message['suggestedAction']) => {
    if (!action) return;
    if (action.type === 'add_to_cart' && action.itemId && onQuickAddFoodItem) {
      const item = availableFoodItems.find((i) => i.id === action.itemId);
      if (item) onQuickAddFoodItem(item);
    } else if (action.type === 'open_deals' && onNavigateTab) {
      onNavigateTab('deals');
    } else if (action.type === 'open_menu' && onNavigateTab) {
      onNavigateTab('menu');
    } else if (action.type === 'track_order' && onNavigateTab) {
      onNavigateTab('tracking');
    }
  };

  const handleResetChat = () => {
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        role: 'assistant',
        content:
          "Chat reset! Ask me anything about our flame-seared burgers, wood-fired pizzas, secret sauces, or branch locations.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Floating Action Button (Closed State) */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="group relative flex items-center gap-3 px-4 py-3.5 bg-gradient-to-r from-red-600 via-amber-600 to-red-600 bg-size-200 hover:bg-pos-100 text-white rounded-full shadow-2xl shadow-red-950/60 hover:scale-105 transition-all duration-300 border border-amber-500/40"
          title="Open AI Food Concierge Chat"
        >
          <div className="relative">
            <Bot className="w-5 h-5 text-white animate-bounce" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-black" />
          </div>
          <div className="text-left text-xs pr-1">
            <span className="block font-bold leading-none uppercase tracking-wide">
              Chef Smash AI
            </span>
            <span className="text-[10px] text-amber-200 font-medium">Ask for food advice</span>
          </div>
        </button>
      )}

      {/* Expanded Chat Drawer / Window */}
      {isOpen && (
        <div className="relative w-[92vw] sm:w-[390px] h-[540px] max-h-[85vh] bg-[#121319] border border-zinc-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-red-950/80 via-[#181922] to-[#14151b] border-b border-zinc-800/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-red-600 to-amber-600 flex items-center justify-center text-white shadow-md">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white uppercase font-display tracking-wider flex items-center gap-1.5">
                  <span>Chef Smash AI Concierge</span>
                  <Sparkles className="w-3 h-3 text-amber-400" />
                </h3>
                <span className="text-[10px] text-emerald-400 font-medium block">
                  Online · Powered by Gemini
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={handleResetChat}
                className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800/80 transition-colors"
                title="Restart Chat"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800/80 transition-colors"
                title="Close Chat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages Feed */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-[#0e0f14]/80">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.role === 'assistant' && (
                  <div className="w-7 h-7 rounded-lg bg-red-600/20 text-red-400 flex items-center justify-center shrink-0 mt-0.5 border border-red-500/30">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                )}

                <div
                  className={`max-w-[82%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-red-600 text-white font-medium rounded-br-sm shadow-md'
                      : 'bg-[#181a24] text-zinc-200 border border-zinc-800 rounded-bl-sm'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.content}</p>

                  {/* Interactive Button in Assistant message */}
                  {msg.suggestedAction && (
                    <button
                      onClick={() => handleActionClick(msg.suggestedAction)}
                      className="mt-2.5 w-full py-1.5 px-3 bg-red-600/20 hover:bg-red-600/30 text-amber-300 hover:text-white border border-amber-500/40 rounded-xl font-semibold text-[11px] flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>{msg.suggestedAction.label}</span>
                    </button>
                  )}

                  <span className="block text-[9px] text-zinc-400 text-right mt-1 opacity-70">
                    {msg.timestamp}
                  </span>
                </div>

                {msg.role === 'user' && (
                  <div className="w-7 h-7 rounded-lg bg-zinc-800 text-zinc-300 flex items-center justify-center shrink-0 mt-0.5 border border-zinc-700">
                    <User className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-2.5 items-center text-xs text-zinc-400 pl-1">
                <div className="w-7 h-7 rounded-lg bg-red-600/20 text-red-400 flex items-center justify-center border border-red-500/30">
                  <Bot className="w-3.5 h-3.5" />
                </div>
                <div className="bg-[#181a24] border border-zinc-800 px-3 py-2 rounded-2xl flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                  <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse delay-100" />
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse delay-200" />
                  <span className="text-[11px] text-zinc-400 ml-1">Chef Smash is thinking...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Prompts Carousel */}
          <div className="px-3 py-2 bg-[#121319] border-t border-zinc-800/60 overflow-x-auto flex gap-1.5 scrollbar-none no-scrollbar">
            {QUICK_PROMPTS.map((prompt) => (
              <button
                key={prompt}
                onClick={() => sendMessage(prompt)}
                disabled={isLoading}
                className="px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800 text-[11px] font-medium whitespace-nowrap shrink-0 transition-colors disabled:opacity-50"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <div className="p-3 bg-[#151720] border-t border-zinc-800 flex items-center gap-2">
            <input
              ref={inputRef}
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  sendMessage();
                }
              }}
              placeholder="Ask Chef Smash anything..."
              className="flex-1 px-3.5 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-colors"
            />
            <button
              onClick={() => sendMessage()}
              disabled={!inputMessage.trim() || isLoading}
              className="p-2.5 bg-red-600 hover:bg-red-500 disabled:bg-zinc-800 text-white disabled:text-zinc-600 rounded-xl transition-all shadow-md shadow-red-950/40"
              title="Send Message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
