import React, { useState } from 'react';
import { X, CheckCircle2, MessageCircle, MapPin, Phone, User, Bike, Store, CreditCard, Banknote } from 'lucide-react';
import { CartItem, Order, PromoCode } from '../types.ts';
import { RESTAURANT_CONFIG } from '../data/initialMenu.ts';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  appliedPromo: PromoCode | null;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  appliedPromo,
  onOrderSuccess,
}) => {
  if (!isOpen) return null;

  const [orderType, setOrderType] = useState<'delivery' | 'pickup'>('delivery');
  const [customerName, setCustomerName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [selectedArea, setSelectedArea] = useState<string>('Gulberg / Cantt');
  const [notes, setNotes] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'card_on_delivery' | 'whatsapp'>('cod');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [validationError, setValidationError] = useState<string>('');

  // Calculations
  const subtotal = cartItems.reduce((sum, item) => sum + item.totalPrice, 0);
  const deliveryFee =
    orderType === 'pickup' || subtotal >= RESTAURANT_CONFIG.freeDeliveryThreshold
      ? 0
      : RESTAURANT_CONFIG.deliveryFee;
  const discountAmount = appliedPromo ? Math.round((subtotal * appliedPromo.discountPercent) / 100) : 0;
  const total = Math.max(0, subtotal + deliveryFee - discountAmount);

  // Generate WhatsApp message template
  const generateWhatsAppMessage = (orderId: string) => {
    let msg = `🍔 *NEW ORDER: #${orderId}*\n`;
    msg += `*Restaurant:* ${RESTAURANT_CONFIG.name}\n\n`;
    msg += `*Customer Details:*\n`;
    msg += `• Name: ${customerName || 'Customer'}\n`;
    msg += `• Phone: ${phone || 'N/A'}\n`;
    msg += `• Type: ${orderType === 'delivery' ? 'Home Delivery' : 'Self Pickup'}\n`;
    if (orderType === 'delivery') {
      msg += `• Address: ${address}, ${selectedArea}\n`;
    }
    if (notes) {
      msg += `• Notes: ${notes}\n`;
    }
    msg += `\n*Items Ordered:*\n`;
    cartItems.forEach((ci, idx) => {
      msg += `${idx + 1}. *${ci.item.name}* (x${ci.quantity})`;
      if (ci.selectedSize) msg += ` - ${ci.selectedSize}`;
      if (ci.selectedExtras.length > 0) {
        msg += ` (+${ci.selectedExtras.map((e) => e.name).join(', ')})`;
      }
      msg += ` = Rs. ${ci.totalPrice}\n`;
    });
    msg += `\n*Financials:*\n`;
    msg += `• Subtotal: Rs. ${subtotal}\n`;
    msg += `• Delivery Fee: ${deliveryFee === 0 ? 'FREE' : `Rs. ${deliveryFee}`}\n`;
    if (discountAmount > 0) {
      msg += `• Voucher Discount: -Rs. ${discountAmount} (${appliedPromo?.code})\n`;
    }
    msg += `• *TOTAL PAYABLE: Rs. ${total}*\n`;
    msg += `• Payment Method: ${
      paymentMethod === 'cod' ? 'Cash on Delivery' : paymentMethod === 'card_on_delivery' ? 'Card on Delivery' : 'WhatsApp Order'
    }\n\n`;
    msg += `Please confirm my order and share preparation time. Thank you!`;
    return encodeURIComponent(msg);
  };

  const handlePlaceOrder = (methodOverride?: 'cod' | 'card_on_delivery' | 'whatsapp') => {
    setValidationError('');

    if (!customerName.trim()) {
      setValidationError('Please enter your full name');
      return;
    }
    if (!phone.trim() || phone.trim().length < 8) {
      setValidationError('Please enter a valid mobile number (e.g. 0300-1234567)');
      return;
    }
    if (orderType === 'delivery' && !address.trim()) {
      setValidationError('Please enter your complete delivery street address');
      return;
    }

    setIsSubmitting(true);

    const activePayment = methodOverride || paymentMethod;
    const orderId = `CS-${Math.floor(1000 + Math.random() * 9000)}`;

    const newOrder: Order = {
      id: orderId,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      items: cartItems,
      subtotal,
      deliveryFee,
      discount: discountAmount,
      promoCode: appliedPromo?.code,
      total,
      type: orderType,
      paymentMethod: activePayment,
      customer: {
        name: customerName.trim(),
        phone: phone.trim(),
        address: orderType === 'delivery' ? address.trim() : 'Pickup from Gulberg Main Branch',
        area: selectedArea,
        notes: notes.trim(),
      },
      status: 'received',
      estimatedDeliveryMinutes: orderType === 'delivery' ? 30 : 15,
      rider:
        orderType === 'delivery'
          ? {
              name: 'Hamza Tariq',
              phone: '+92 301 9876543',
              vehicle: 'Honda CG 125 (LEA-4892)',
            }
          : undefined,
    };

    if (activePayment === 'whatsapp') {
      const waMsg = generateWhatsAppMessage(orderId);
      const waUrl = `https://wa.me/${RESTAURANT_CONFIG.whatsappNumber}?text=${waMsg}`;
      window.open(waUrl, '_blank');
    }

    setTimeout(() => {
      setIsSubmitting(false);
      onOrderSuccess(newOrder);
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl bg-[#14151b] border border-zinc-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-zinc-800 bg-[#161821] flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white font-display uppercase tracking-wide">
              Fast Checkout & Delivery
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Cash on delivery, card, or direct instant WhatsApp ordering
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content form */}
        <div className="p-6 space-y-6 max-h-[72vh] overflow-y-auto">
          {/* Order Type Toggle: Delivery vs Pickup */}
          <div>
            <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2">
              Select Fulfillment Mode
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setOrderType('delivery')}
                className={`p-3.5 rounded-2xl border flex items-center justify-center gap-2.5 transition-all ${
                  orderType === 'delivery'
                    ? 'border-red-500 bg-red-600/15 text-white shadow-md'
                    : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <Bike className="w-4 h-4 text-red-500" />
                <span className="text-xs font-bold uppercase">Doorstep Delivery</span>
              </button>
              <button
                type="button"
                onClick={() => setOrderType('pickup')}
                className={`p-3.5 rounded-2xl border flex items-center justify-center gap-2.5 transition-all ${
                  orderType === 'pickup'
                    ? 'border-red-500 bg-red-600/15 text-white shadow-md'
                    : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <Store className="w-4 h-4 text-amber-500" />
                <span className="text-xs font-bold uppercase">Self Pickup (Branch)</span>
              </button>
            </div>
          </div>

          {/* Customer Details */}
          <div className="space-y-4">
            <h3 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
              Customer Information
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Your Full Name *</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Ali Khan"
                    className="w-full pl-9 pr-3 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Mobile Number (WhatsApp) *</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="0300-1234567"
                    className="w-full pl-9 pr-3 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 font-mono"
                  />
                </div>
              </div>
            </div>

            {orderType === 'delivery' && (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] text-zinc-400 mb-1">
                      Street Address / House # *
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 w-4 h-4 text-zinc-500" />
                      <input
                        type="text"
                        required
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="House / Flat #, Street, Block, Landmark"
                        className="w-full pl-9 pr-3 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Sector / Area</label>
                    <select
                      value={selectedArea}
                      onChange={(e) => setSelectedArea(e.target.value)}
                      className="w-full px-3 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
                    >
                      <option value="Gulberg / Cantt">Gulberg / Cantt</option>
                      <option value="DHA Phase 1-6">DHA Phase 1-6</option>
                      <option value="Johar Town / Model Town">Johar Town / Model Town</option>
                      <option value="Bahria Town">Bahria Town</option>
                      <option value="F-7 / F-8 Islamabad">F-7 / F-8 Islamabad</option>
                      <option value="Clifton / DHA Karachi">Clifton / DHA Karachi</option>
                    </select>
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-[11px] text-zinc-400 mb-1">Special Rider Notes (Optional)</label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Ring bell twice, deliver to security guard"
                className="w-full px-3 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          {/* Payment Method Selector */}
          <div>
            <h3 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2">
              Payment Method
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => setPaymentMethod('cod')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  paymentMethod === 'cod'
                    ? 'border-red-500 bg-red-600/10 text-white'
                    : 'border-zinc-800 bg-zinc-900/40 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Banknote className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-bold text-white">Cash On Delivery</span>
                </div>
                <span className="text-[10px] text-zinc-400 block">Pay cash to rider</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('card_on_delivery')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  paymentMethod === 'card_on_delivery'
                    ? 'border-red-500 bg-red-600/10 text-white'
                    : 'border-zinc-800 bg-zinc-900/40 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <CreditCard className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-bold text-white">Card Machine</span>
                </div>
                <span className="text-[10px] text-zinc-400 block">Rider brings POS</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('whatsapp')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  paymentMethod === 'whatsapp'
                    ? 'border-emerald-500 bg-emerald-600/15 text-white'
                    : 'border-zinc-800 bg-zinc-900/40 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-bold text-white">WhatsApp Order</span>
                </div>
                <span className="text-[10px] text-zinc-400 block">Send to WhatsApp</span>
              </button>
            </div>
          </div>

          {/* Validation Error Banner */}
          {validationError && (
            <div className="p-3 bg-red-950/60 border border-red-800 rounded-xl text-xs text-red-300">
              {validationError}
            </div>
          )}

          {/* Order Summary Recap */}
          <div className="p-4 bg-zinc-900/60 border border-zinc-800/80 rounded-2xl space-y-2 text-xs">
            <div className="flex justify-between text-zinc-400">
              <span>Items Total ({cartItems.reduce((acc, c) => acc + c.quantity, 0)} items)</span>
              <span className="text-white font-mono tabular-nums">Rs. {subtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-zinc-400">
              <span>Delivery Fee ({orderType === 'pickup' ? 'Self Pickup' : 'Doorstep'})</span>
              <span className="text-white font-mono tabular-nums">
                {deliveryFee === 0 ? <span className="text-emerald-400">FREE</span> : `Rs. ${deliveryFee}`}
              </span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-400">
                <span>Voucher Discount</span>
                <span className="font-mono tabular-nums">-Rs. {discountAmount.toLocaleString()}</span>
              </div>
            )}
            <div className="pt-2 border-t border-zinc-800 flex justify-between text-sm font-bold text-white">
              <span>Grand Total</span>
              <span className="text-amber-400 font-mono tabular-nums text-base">
                Rs. {total.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-5 sm:p-6 bg-[#161821] border-t border-zinc-800 flex flex-col sm:flex-row items-center gap-3">
          {/* Quick WhatsApp button */}
          <button
            type="button"
            disabled={isSubmitting}
            onClick={() => handlePlaceOrder('whatsapp')}
            className="w-full sm:w-auto px-5 py-3.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Order via WhatsApp</span>
          </button>

          {/* Primary Place Order button */}
          <button
            type="button"
            disabled={isSubmitting}
            onClick={() => handlePlaceOrder()}
            className="w-full sm:flex-1 py-3.5 px-6 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-red-900/40 transition-all flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{isSubmitting ? 'Confirming Order...' : 'Confirm Order Now'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
