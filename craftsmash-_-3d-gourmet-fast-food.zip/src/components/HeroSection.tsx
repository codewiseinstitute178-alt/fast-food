import React from 'react';
import { ArrowRight, Flame, Clock, Award, ShieldCheck, MessageCircle } from 'lucide-react';
import { ThreeBurger } from './ThreeBurger.tsx';
import { RESTAURANT_CONFIG } from '../data/initialMenu.ts';

interface HeroSectionProps {
  onOrderNow: () => void;
  onExploreMenu: () => void;
  onOpenWhatsApp: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOrderNow,
  onExploreMenu,
  onOpenWhatsApp,
}) => {
  return (
    <section className="relative pt-6 pb-16 md:pt-10 md:pb-24 overflow-hidden">
      {/* Background radial gradient glow */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-red-600/10 blur-[140px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Column: Headlines & High-Conversion Action */}
          <div className="lg:col-span-5 text-left z-10">
            {/* Clean unboxed editorial kicker */}
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-amber-400 uppercase mb-4">
              <Flame className="w-4 h-4 text-red-500 animate-pulse" />
              <span>Artisanal Flame-Seared Smash Burgers</span>
              <span aria-hidden="true" className="text-zinc-600">·</span>
              <span className="text-zinc-400">Lahore · Islamabad · Karachi</span>
            </div>

            {/* Hero Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold uppercase font-display text-white tracking-tight leading-[0.95] mb-5 text-balance">
              BIG FLAVOUR.{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-amber-500 to-orange-400">
                UNFORGETTABLE
              </span>{' '}
              BITES.
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-zinc-300 font-normal leading-relaxed mb-8 max-w-xl">
              Freshly prepared. Deliciously served. Made for every craving. Double-smashed 100% prime Angus beef with caramelized edges, toasted brioche, and house-crafted sauces.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 mb-10">
              <button
                onClick={onOrderNow}
                className="px-7 py-4 bg-red-600 hover:bg-red-500 text-white font-bold rounded-2xl shadow-xl shadow-red-900/40 hover:shadow-red-800/60 transition-all flex items-center gap-2.5 text-sm uppercase tracking-wide group"
              >
                <span>Order Now</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onExploreMenu}
                className="px-6 py-4 bg-zinc-900/90 hover:bg-zinc-800 text-zinc-200 hover:text-white font-bold rounded-2xl border border-zinc-700/80 transition-all text-sm uppercase tracking-wide"
              >
                Explore Our Menu
              </button>

              <button
                onClick={onOpenWhatsApp}
                className="px-4 py-4 bg-emerald-700/30 hover:bg-emerald-600/40 text-emerald-300 hover:text-white font-semibold rounded-2xl border border-emerald-500/40 transition-all text-xs flex items-center gap-2"
                title="Quick WhatsApp Order"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span className="hidden sm:inline">WhatsApp Order</span>
              </button>
            </div>

            {/* Value Proposition Strip */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-zinc-800/80">
              <div>
                <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-1">
                  <Clock className="w-3.5 h-3.5 text-amber-500" />
                  <span>Speed</span>
                </div>
                <div className="text-sm font-bold text-white tabular-nums">25-35 Min</div>
                <div className="text-[11px] text-zinc-500">Hot Doorstep Delivery</div>
              </div>

              <div>
                <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-1">
                  <Award className="w-3.5 h-3.5 text-red-500" />
                  <span>Quality</span>
                </div>
                <div className="text-sm font-bold text-white">100% Angus</div>
                <div className="text-[11px] text-zinc-500">Fresh, Never Frozen</div>
              </div>

              <div>
                <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Rating</span>
                </div>
                <div className="text-sm font-bold text-white tabular-nums">4.9 / 5.0 ★</div>
                <div className="text-[11px] text-zinc-500">12,000+ Happy Foodies</div>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive 3D Burger & Food Showcase */}
          <div className="lg:col-span-7">
            <ThreeBurger onOrderNow={onOrderNow} />
          </div>
        </div>
      </div>
    </section>
  );
};
