import React, { useState } from 'react';
import { Search, Flame, Plus, Clock, SlidersHorizontal, Sparkles } from 'lucide-react';
import { FoodItem, FoodCategory } from '../types.ts';

interface MenuSectionProps {
  items: FoodItem[];
  onSelectItem: (item: FoodItem) => void;
  onQuickAdd: (item: FoodItem) => void;
}

const CATEGORIES: { id: FoodCategory | 'all'; label: string }[] = [
  { id: 'all', label: 'All Items' },
  { id: 'burgers', label: 'Burgers & Zingers' },
  { id: 'pizza', label: 'Artisan Pizzas' },
  { id: 'chicken', label: 'Fried Chicken' },
  { id: 'fries', label: 'Loaded Fries' },
  { id: 'sandwiches', label: 'Wraps & Subs' },
  { id: 'combos', label: 'Deals & Combos' },
  { id: 'drinks_desserts', label: 'Drinks & Desserts' },
];

export const MenuSection: React.FC<MenuSectionProps> = ({
  items,
  onSelectItem,
  onQuickAdd,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<FoodCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterSpicyOnly, setFilterSpicyOnly] = useState<boolean>(false);
  const [filterPopularOnly, setFilterPopularOnly] = useState<boolean>(false);

  // Filter items
  const filteredItems = items.filter((item) => {
    // Category match
    if (selectedCategory !== 'all' && item.category !== selectedCategory) {
      return false;
    }
    // Search match
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = item.name.toLowerCase().includes(q);
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchBadge = item.badge?.toLowerCase().includes(q);
      if (!matchName && !matchDesc && !matchBadge) return false;
    }
    // Spicy filter
    if (filterSpicyOnly && (!item.spicyLevel || item.spicyLevel < 2)) {
      return false;
    }
    // Popular filter
    if (filterPopularOnly && !item.isPopular) {
      return false;
    }
    return true;
  });

  return (
    <section id="menu-section" className="py-16 md:py-24 bg-[#0a0b0e] border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold tracking-wider text-red-500 uppercase mb-2">
            <Flame className="w-4 h-4" />
            <span>Mastercrafted Menu</span>
            <span aria-hidden="true" className="text-zinc-600">·</span>
            <span className="text-zinc-400">Cooked to Order</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold uppercase font-display text-white tracking-tight leading-tight">
            CRAVE-WORTHY FLAVOURS
          </h2>
          <p className="text-sm sm:text-base text-zinc-400 mt-2">
            Handcrafted with 100% prime ingredients, sizzling hot off the griddle and delivered in prime condition.
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-8">
          {/* Search box */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search burgers, pizzas, fries, combos..."
              className="w-full pl-10 pr-4 py-3 bg-[#14151b] border border-zinc-800 rounded-2xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-zinc-500 hover:text-white"
              >
                Clear
              </button>
            )}
          </div>

          {/* Quick preference toggles */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFilterPopularOnly(!filterPopularOnly)}
              className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all flex items-center gap-1.5 ${
                filterPopularOnly
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                  : 'bg-[#14151b] text-zinc-400 border-zinc-800 hover:border-zinc-700'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Bestsellers</span>
            </button>

            <button
              onClick={() => setFilterSpicyOnly(!filterSpicyOnly)}
              className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all flex items-center gap-1.5 ${
                filterSpicyOnly
                  ? 'bg-red-500/20 text-red-300 border-red-500/50'
                  : 'bg-[#14151b] text-zinc-400 border-zinc-800 hover:border-zinc-700'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-red-500" />
              <span>Fiery Spicy</span>
            </button>
          </div>
        </div>

        {/* Category Pill Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none no-scrollbar">
          {CATEGORIES.map((cat) => {
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition-all ${
                  isActive
                    ? 'bg-red-600 text-white shadow-lg shadow-red-900/30'
                    : 'bg-[#14151b] text-zinc-400 hover:text-white hover:bg-zinc-800 border border-zinc-800/80'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Menu Grid */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-[#14151b]/40 rounded-3xl border border-zinc-800/60 p-8">
            <SlidersHorizontal className="w-8 h-8 text-zinc-600 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-white">No items found</h3>
            <p className="text-xs text-zinc-500 mt-1 max-w-sm mx-auto">
              We couldn't find matching food items. Try searching for a different item or clear your filters.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setFilterSpicyOnly(false);
                setFilterPopularOnly(false);
              }}
              className="mt-4 px-4 py-2 bg-zinc-800 text-zinc-200 text-xs font-medium rounded-xl hover:bg-zinc-700 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="group bg-[#14151b] border border-zinc-800/80 hover:border-red-500/40 rounded-3xl overflow-hidden flex flex-col transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-red-950/20"
              >
                {/* Food Image Container */}
                <div
                  onClick={() => onSelectItem(item)}
                  className="relative h-56 sm:h-60 w-full overflow-hidden bg-zinc-900 cursor-pointer"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#14151b] via-transparent to-black/20" />

                  {/* Top Badges */}
                  <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                    {item.badge && (
                      <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold uppercase tracking-wider bg-red-600 text-white shadow-md">
                        {item.badge}
                      </span>
                    )}
                    {item.isPopular && !item.badge && (
                      <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold uppercase tracking-wider bg-amber-500 text-black shadow-md">
                        Bestseller
                      </span>
                    )}
                  </div>

                  {/* Spicy indicator */}
                  {item.spicyLevel && item.spicyLevel > 0 ? (
                    <div className="absolute top-3 right-3 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[11px] font-semibold text-red-400 flex items-center gap-1">
                      <Flame className="w-3 h-3 text-red-500 fill-red-500" />
                      <span>{item.spicyLevel === 3 ? 'Extra Hot' : 'Spicy'}</span>
                    </div>
                  ) : null}

                  {/* Out of Stock Overlay */}
                  {!item.isAvailable && (
                    <div className="absolute inset-0 bg-black/80 flex items-center justify-center">
                      <span className="px-4 py-1.5 rounded-xl bg-zinc-800 text-zinc-400 text-xs font-bold uppercase tracking-widest border border-zinc-700">
                        Sold Out
                      </span>
                    </div>
                  )}
                </div>

                {/* Card Content Body */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Category kicker */}
                    <div className="text-[11px] font-semibold text-zinc-500 uppercase tracking-wider mb-1">
                      {item.category.replace('_', ' & ')}
                    </div>

                    {/* Food Name */}
                    <h3
                      onClick={() => onSelectItem(item)}
                      className="text-lg font-bold text-white font-display uppercase tracking-wide group-hover:text-red-400 transition-colors cursor-pointer line-clamp-1"
                    >
                      {item.name}
                    </h3>

                    {/* Description */}
                    <p className="text-xs text-zinc-400 mt-1 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  {/* Card Footer: Specs, Price, and Actions */}
                  <div className="pt-4 mt-4 border-t border-zinc-800/80 flex items-center justify-between gap-3">
                    <div>
                      <span className="text-[10px] text-zinc-500 block uppercase font-medium">Price</span>
                      <span className="text-lg font-bold text-white font-mono tabular-nums">
                        Rs. {item.price.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onSelectItem(item)}
                        disabled={!item.isAvailable}
                        className="px-3 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-medium transition-colors"
                      >
                        Customize
                      </button>

                      <button
                        onClick={() => onQuickAdd(item)}
                        disabled={!item.isAvailable}
                        className="p-2 sm:px-3 sm:py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all shadow-md shadow-red-950/40 flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
                        title="Add to cart"
                      >
                        <Plus className="w-4 h-4" />
                        <span className="hidden sm:inline">Add</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
