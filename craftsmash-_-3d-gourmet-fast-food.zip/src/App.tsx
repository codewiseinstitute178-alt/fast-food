import React, { useState, useEffect } from 'react';
import { FoodItem, CartItem, Order, PromoCode, CustomizationOption } from './types.ts';
import {
  INITIAL_FOOD_ITEMS,
  INITIAL_PROMO_CODES,
  RESTAURANT_CONFIG,
} from './data/initialMenu.ts';
import { Navbar } from './components/Navbar.tsx';
import { HeroSection } from './components/HeroSection.tsx';
import { MenuSection } from './components/MenuSection.tsx';
import { SpecialDealsSection } from './components/SpecialDealsSection.tsx';
import { AboutSection } from './components/AboutSection.tsx';
import { ReviewsSection } from './components/ReviewsSection.tsx';
import { ItemCustomizeModal } from './components/ItemCustomizeModal.tsx';
import { CartDrawer } from './components/CartDrawer.tsx';
import { CheckoutModal } from './components/CheckoutModal.tsx';
import { OrderTrackingModal } from './components/OrderTrackingModal.tsx';
import { AdminDashboard } from './components/AdminDashboard.tsx';
import { Footer } from './components/Footer.tsx';
import { AIAgentChatbot } from './components/AIAgentChatbot.tsx';

export default function App() {
  // Navigation state
  const [activeTab, setActiveTab] = useState<'home' | 'menu' | 'deals' | 'tracking' | 'about' | 'admin'>('home');

  // Menu items state (persisted in LocalStorage)
  const [foodItems, setFoodItems] = useState<FoodItem[]>(() => {
    try {
      const saved = localStorage.getItem('craftsmash_menu_items');
      return saved ? JSON.parse(saved) : INITIAL_FOOD_ITEMS;
    } catch {
      return INITIAL_FOOD_ITEMS;
    }
  });

  // Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('craftsmash_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Orders state
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('craftsmash_orders');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    // Default initial mock order so tracking is populated right away
    return [
      {
        id: 'CS-4892',
        createdAt: '10:15 PM',
        items: [
          {
            cartItemId: 'init-1',
            item: INITIAL_FOOD_ITEMS[0],
            quantity: 2,
            selectedSize: 'Double Patty (8oz)',
            selectedExtras: [{ name: 'Extra Cheddar Slice', price: 120 }],
            notes: 'Extra crispy smash edges',
            unitPrice: 1170,
            totalPrice: 2340,
          },
          {
            cartItemId: 'init-2',
            item: INITIAL_FOOD_ITEMS[7], // loaded fries
            quantity: 1,
            selectedExtras: [],
            unitPrice: 690,
            totalPrice: 690,
          },
        ],
        subtotal: 3030,
        deliveryFee: 0,
        discount: 300,
        promoCode: 'SMASH20',
        total: 2730,
        type: 'delivery',
        paymentMethod: 'cod',
        customer: {
          name: 'Hamza Malik',
          phone: '0321-9876543',
          address: 'House 42, Street 8, Sector Y, DHA Phase 3',
          area: 'DHA Phase 1-6',
          notes: 'Call before arriving',
        },
        status: 'out_for_delivery',
        estimatedDeliveryMinutes: 12,
        rider: {
          name: 'Usman Ghani',
          phone: '+92 300 7654321',
          vehicle: 'Honda 125 (LEA-7789)',
        },
      },
    ];
  });

  // Promo Codes state
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>(() => {
    try {
      const saved = localStorage.getItem('craftsmash_promos');
      return saved ? JSON.parse(saved) : INITIAL_PROMO_CODES;
    } catch {
      return INITIAL_PROMO_CODES;
    }
  });

  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(null);

  // Modals & Drawers state
  const [customizingItem, setCustomizingItem] = useState<FoodItem | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [activeTrackingOrderId, setActiveTrackingOrderId] = useState<string | undefined>('CS-4892');
  const [toastMessage, setToastMessage] = useState<string>('');

  // Save changes to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('craftsmash_menu_items', JSON.stringify(foodItems));
    } catch {}
  }, [foodItems]);

  useEffect(() => {
    try {
      localStorage.setItem('craftsmash_cart', JSON.stringify(cartItems));
    } catch {}
  }, [cartItems]);

  useEffect(() => {
    try {
      localStorage.setItem('craftsmash_orders', JSON.stringify(orders));
    } catch {}
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem('craftsmash_promos', JSON.stringify(promoCodes));
    } catch {}
  }, [promoCodes]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage('');
    }, 2800);
  };

  // Cart Handlers
  const handleAddToCart = (
    item: FoodItem,
    quantity: number,
    selectedSize: string | undefined,
    selectedExtras: CustomizationOption[],
    notes: string,
    finalUnitPrice: number
  ) => {
    const newCartItem: CartItem = {
      cartItemId: `${item.id}-${Date.now()}`,
      item,
      quantity,
      selectedSize,
      selectedExtras,
      notes,
      unitPrice: finalUnitPrice,
      totalPrice: finalUnitPrice * quantity,
    };

    setCartItems((prev) => [...prev, newCartItem]);
    showToast(`Added ${quantity}x ${item.name} to cart!`);
  };

  const handleQuickAdd = (item: FoodItem) => {
    // If item has sizes, open customize modal so user chooses size
    if (item.sizes && item.sizes.length > 0) {
      setCustomizingItem(item);
      return;
    }

    const newCartItem: CartItem = {
      cartItemId: `${item.id}-${Date.now()}`,
      item,
      quantity: 1,
      selectedExtras: [],
      unitPrice: item.price,
      totalPrice: item.price,
    };

    setCartItems((prev) => [...prev, newCartItem]);
    showToast(`Added 1x ${item.name} to cart!`);
  };

  const handleUpdateQuantity = (cartItemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveItem(cartItemId);
      return;
    }
    setCartItems((prev) =>
      prev.map((c) =>
        c.cartItemId === cartItemId
          ? {
              ...c,
              quantity: newQuantity,
              totalPrice: c.unitPrice * newQuantity,
            }
          : c
      )
    );
  };

  const handleRemoveItem = (cartItemId: string) => {
    setCartItems((prev) => prev.filter((c) => c.cartItemId !== cartItemId));
  };

  // Promo Handlers
  const handleApplyPromo = (code: string): boolean => {
    const subtotal = cartItems.reduce((sum, it) => sum + it.totalPrice, 0);
    const found = promoCodes.find((p) => p.code === code && p.active);
    if (!found) return false;

    if (subtotal < found.minOrder) {
      showToast(`Order must be at least Rs. ${found.minOrder} to use ${code}`);
      return false;
    }

    setAppliedPromo(found);
    showToast(`Voucher ${code} applied! ${found.discountPercent}% discount`);
    return true;
  };

  const handleRemovePromo = () => {
    setAppliedPromo(null);
  };

  // Order submission
  const handleOrderSuccess = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);
    setCartItems([]);
    setAppliedPromo(null);
    setActiveTrackingOrderId(newOrder.id);
    setActiveTab('tracking');
    showToast(`Order #${newOrder.id} confirmed! Tracking status is live.`);
  };

  // Advance Order Status Simulation
  const handleAdvanceOrderStatus = (orderId: string) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id !== orderId) return ord;
        let nextStatus: Order['status'] = ord.status;
        if (ord.status === 'received') nextStatus = 'kitchen';
        else if (ord.status === 'kitchen') nextStatus = 'packing';
        else if (ord.status === 'packing') nextStatus = 'out_for_delivery';
        else if (ord.status === 'out_for_delivery') nextStatus = 'delivered';

        return { ...ord, status: nextStatus };
      })
    );
  };

  // Open direct WhatsApp order chat
  const handleOpenDirectWhatsApp = () => {
    const text = encodeURIComponent(
      `Hi ${RESTAURANT_CONFIG.name}! I would like to place an order from your online menu.`
    );
    window.open(`https://wa.me/${RESTAURANT_CONFIG.whatsappNumber}?text=${text}`, '_blank');
  };

  // Calculations for Navbar badge
  const totalCartCount = cartItems.reduce((sum, it) => sum + it.quantity, 0);
  const cartSubtotal = cartItems.reduce((sum, it) => sum + it.totalPrice, 0);

  // Combos list
  const comboMeals = foodItems.filter((i) => i.category === 'combos');

  return (
    <div className="min-h-screen bg-[#0c0d10] text-[#f4f4f6] flex flex-col font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 px-4 py-3 bg-red-600 text-white text-xs font-bold uppercase tracking-wider rounded-2xl shadow-2xl flex items-center gap-2 animate-bounce">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={totalCartCount}
        cartTotal={cartSubtotal}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Main Dynamic Content View */}
      <main className="flex-1">
        {/* TAB: HOME */}
        {activeTab === 'home' && (
          <>
            <HeroSection
              onOrderNow={() => {
                const elem = document.getElementById('menu-section');
                if (elem) elem.scrollIntoView({ behavior: 'smooth' });
                else setActiveTab('menu');
              }}
              onExploreMenu={() => {
                const elem = document.getElementById('menu-section');
                if (elem) elem.scrollIntoView({ behavior: 'smooth' });
                else setActiveTab('menu');
              }}
              onOpenWhatsApp={handleOpenDirectWhatsApp}
            />

            <MenuSection
              items={foodItems}
              onSelectItem={(item) => setCustomizingItem(item)}
              onQuickAdd={handleQuickAdd}
            />

            <SpecialDealsSection
              comboItems={comboMeals}
              onSelectCombo={(item) => setCustomizingItem(item)}
              onQuickAdd={handleQuickAdd}
              onViewAllMenu={() => setActiveTab('menu')}
            />

            <AboutSection />

            <ReviewsSection />
          </>
        )}

        {/* TAB: MENU */}
        {activeTab === 'menu' && (
          <div className="pt-6">
            <MenuSection
              items={foodItems}
              onSelectItem={(item) => setCustomizingItem(item)}
              onQuickAdd={handleQuickAdd}
            />
          </div>
        )}

        {/* TAB: DEALS */}
        {activeTab === 'deals' && (
          <div className="pt-6">
            <SpecialDealsSection
              comboItems={comboMeals}
              onSelectCombo={(item) => setCustomizingItem(item)}
              onQuickAdd={handleQuickAdd}
              onViewAllMenu={() => setActiveTab('menu')}
            />
          </div>
        )}

        {/* TAB: ORDER TRACKING */}
        {activeTab === 'tracking' && (
          <OrderTrackingModal
            orders={orders}
            activeOrderId={activeTrackingOrderId}
            onSelectOrder={(id) => setActiveTrackingOrderId(id)}
            onAdvanceOrderStatus={handleAdvanceOrderStatus}
            onClose={() => setActiveTab('home')}
          />
        )}

        {/* TAB: ABOUT & BRANCHES */}
        {activeTab === 'about' && (
          <div className="pt-6">
            <AboutSection />
            <ReviewsSection />
          </div>
        )}

        {/* TAB: ADMIN DASHBOARD */}
        {activeTab === 'admin' && (
          <AdminDashboard
            foodItems={foodItems}
            onUpdateFoodItems={setFoodItems}
            orders={orders}
            onUpdateOrders={setOrders}
            promoCodes={promoCodes}
            onUpdatePromoCodes={setPromoCodes}
            onClose={() => setActiveTab('home')}
          />
        )}
      </main>

      {/* Cart Drawer Slide-over */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onProceedToCheckout={() => setIsCheckoutOpen(true)}
        appliedPromo={appliedPromo}
        onApplyPromo={handleApplyPromo}
        onRemovePromo={handleRemovePromo}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cartItems}
        appliedPromo={appliedPromo}
        onOrderSuccess={handleOrderSuccess}
      />

      {/* Item Customization Modal */}
      <ItemCustomizeModal
        item={customizingItem}
        onClose={() => setCustomizingItem(null)}
        onAddToCart={handleAddToCart}
      />

      {/* Footer */}
      <Footer
        onNavigateTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenWhatsApp={handleOpenDirectWhatsApp}
      />

      {/* AI Agent Food Concierge Chatbot */}
      <AIAgentChatbot
        onQuickAddFoodItem={handleQuickAdd}
        onNavigateTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        availableFoodItems={foodItems}
      />
    </div>
  );
}
