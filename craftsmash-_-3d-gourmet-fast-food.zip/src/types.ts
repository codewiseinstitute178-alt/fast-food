export type FoodCategory =
  | 'burgers'
  | 'pizza'
  | 'chicken'
  | 'fries'
  | 'sandwiches'
  | 'combos'
  | 'drinks_desserts';

export interface CustomizationOption {
  name: string;
  price: number;
}

export interface FoodItem {
  id: string;
  name: string;
  description: string;
  price: number; // in PKR
  category: FoodCategory;
  image: string;
  badge?: string;
  spicyLevel?: 0 | 1 | 2 | 3;
  calories?: number;
  prepTime?: string;
  isAvailable: boolean;
  isPopular?: boolean;
  extras?: CustomizationOption[];
  sizes?: { name: string; priceMultiplier: number }[];
}

export interface CartItem {
  cartItemId: string;
  item: FoodItem;
  quantity: number;
  selectedSize?: string;
  selectedExtras: CustomizationOption[];
  notes?: string;
  unitPrice: number;
  totalPrice: number;
}

export type OrderStatus =
  | 'received'
  | 'kitchen'
  | 'packing'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled';

export interface OrderCustomer {
  name: string;
  phone: string;
  address: string;
  area: string;
  notes?: string;
}

export interface Order {
  id: string;
  createdAt: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  promoCode?: string;
  total: number;
  type: 'delivery' | 'pickup';
  paymentMethod: 'cod' | 'card_on_delivery' | 'whatsapp';
  customer: OrderCustomer;
  status: OrderStatus;
  estimatedDeliveryMinutes: number;
  rider?: {
    name: string;
    phone: string;
    vehicle: string;
  };
}

export interface PromoCode {
  code: string;
  discountPercent: number; // e.g. 15 for 15% off
  minOrder: number;
  description: string;
  active: boolean;
}
